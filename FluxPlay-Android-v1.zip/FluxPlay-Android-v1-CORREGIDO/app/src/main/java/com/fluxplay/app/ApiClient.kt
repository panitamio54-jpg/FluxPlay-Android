package com.fluxplay.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Base64
import java.util.Locale
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun fetchConfig(): AppConfig = withContext(Dispatchers.IO) {
        val url = BuildConfig.CONFIG_API_URL.toHttpUrl().newBuilder()
            .addQueryParameter("app_key", BuildConfig.CONFIG_API_KEY)
            .build()
        val root = JSONObject(execute(url.toString()))
        if (!root.optBoolean("success", false)) {
            throw IllegalStateException(root.optString("message", "La API del panel rechazó la solicitud."))
        }

        val primary = root.optJSONObject("primary_dns")
        val primaryUrl = when {
            primary != null -> primary.optString("url")
            root.opt("primary_dns") is String -> root.optString("primary_dns")
            else -> ""
        }.trim().trimEnd('/')
        if (primaryUrl.isBlank()) throw IllegalStateException("No hay una DNS principal activa en FluxPlay Control.")

        val backups = mutableListOf<String>()
        val backupArray = root.optJSONArray("backup_dns") ?: JSONArray()
        for (index in 0 until backupArray.length()) {
            val value = backupArray.opt(index)
            val dns = when (value) {
                is JSONObject -> value.optString("url")
                is String -> value
                else -> ""
            }.trim().trimEnd('/')
            if (dns.isNotBlank()) backups += dns
        }

        AppConfig(
            service = root.optString("service", "FluxPlay"),
            maintenance = root.optBoolean("maintenance", false),
            maintenanceMessage = root.optString("maintenance_message", "Servicio temporalmente en mantenimiento."),
            primaryDns = primaryUrl,
            backupDns = backups,
            minimumVersion = root.optString("minimum_version", "1.0.0"),
            latestVersion = root.optString("latest_version", "1.0.0"),
            updateUrl = root.optString("update_url", "")
        )
    }

    suspend fun authenticate(baseUrl: String, username: String, password: String): Session =
        withContext(Dispatchers.IO) {
            val url = playerApiUrl(baseUrl, username, password).build()
            val root = JSONObject(execute(url.toString()))
            val user = root.optJSONObject("user_info")
                ?: throw IllegalStateException("El servidor no devolvió información de usuario.")

            val authenticated = when (val auth = user.opt("auth")) {
                is Number -> auth.toInt() == 1
                is String -> auth == "1" || auth.equals("true", true)
                is Boolean -> auth
                else -> false
            }
            val status = user.optString("status", "")
            if (!authenticated || !status.equals("Active", true)) {
                val message = user.optString("message", "Usuario, contraseña o cuenta no válidos.")
                throw IllegalStateException(message.ifBlank { "La cuenta no está activa." })
            }

            Session(
                baseUrl = baseUrl.trimEnd('/'),
                username = username,
                password = password,
                status = status,
                expiration = formatExpiration(user.optString("exp_date", "")),
                maxConnections = user.optString("max_connections", "1"),
                activeConnections = user.optString("active_cons", "0"),
                isTrial = user.optString("is_trial", "0") == "1"
            )
        }

    suspend fun fetchCategories(session: Session, type: CatalogType): List<Category> =
        withContext(Dispatchers.IO) {
            val url = playerApiUrl(session.baseUrl, session.username, session.password)
                .addQueryParameter("action", type.categoryAction)
                .build()
            val array = JSONArray(execute(url.toString()))
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(Category(item.optString("category_id"), item.optString("category_name", "Sin categoría")))
                }
            }
        }

    suspend fun fetchItems(session: Session, type: CatalogType): List<StreamItem> =
        withContext(Dispatchers.IO) {
            val url = playerApiUrl(session.baseUrl, session.username, session.password)
                .addQueryParameter("action", type.contentAction)
                .build()
            val array = JSONArray(execute(url.toString()))
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val id = if (type == CatalogType.SERIES) item.optInt("series_id") else item.optInt("stream_id")
                    if (id <= 0) continue
                    val info = item.optJSONObject("info")
                    val image = when (type) {
                        CatalogType.SERIES -> item.optString("cover")
                        else -> item.optString("stream_icon")
                    }
                    add(
                        StreamItem(
                            id = id,
                            name = item.optString("name", "Sin nombre"),
                            image = image,
                            categoryId = item.optString("category_id"),
                            extension = item.optString("container_extension", if (type == CatalogType.LIVE) "ts" else "mp4"),
                            description = item.optString("plot", info?.optString("plot", "") ?: ""),
                            rating = item.optString("rating", info?.optString("rating", "") ?: ""),
                            hasArchive = item.optInt("tv_archive", 0) == 1,
                            directSource = item.optString("direct_source", "")
                                .replace("\\/", "/")
                                .replace("&amp;", "&")
                                .trim(),
                            epgChannelId = item.optString("epg_channel_id", "")
                        )
                    )
                }
            }
        }

    suspend fun fetchSeriesEpisodes(session: Session, seriesId: Int): List<Episode> =
        withContext(Dispatchers.IO) {
            val url = playerApiUrl(session.baseUrl, session.username, session.password)
                .addQueryParameter("action", "get_series_info")
                .addQueryParameter("series_id", seriesId.toString())
                .build()
            val root = JSONObject(execute(url.toString()))
            val episodesObject = root.optJSONObject("episodes") ?: return@withContext emptyList()
            val episodes = mutableListOf<Episode>()
            val seasonKeys = episodesObject.keys()
            while (seasonKeys.hasNext()) {
                val seasonKey = seasonKeys.next()
                val season = seasonKey.toIntOrNull() ?: 0
                val array = episodesObject.optJSONArray(seasonKey) ?: continue
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val info = item.optJSONObject("info")
                    val episodeId = item.optInt("id")
                    if (episodeId <= 0) continue
                    episodes += Episode(
                        id = episodeId,
                        title = item.optString("title", "Episodio ${index + 1}"),
                        season = season,
                        number = item.optInt("episode_num", index + 1),
                        extension = item.optString("container_extension", "mp4"),
                        image = info?.optString("movie_image", "") ?: "",
                        description = info?.optString("plot", "") ?: ""
                    )
                }
            }
            episodes.sortedWith(compareBy<Episode> { it.season }.thenBy { it.number })
        }

    suspend fun fetchShortEpg(session: Session, streamId: Int, limit: Int = 4): List<EpgProgram> =
        withContext(Dispatchers.IO) {
            val actions = listOf("get_short_epg", "get_simple_data_table")
            for (action in actions) {
                val url = playerApiUrl(session.baseUrl, session.username, session.password)
                    .addQueryParameter("action", action)
                    .addQueryParameter("stream_id", streamId.toString())
                    .addQueryParameter("limit", limit.toString())
                    .build()
                val parsed = runCatching { parseEpgResponse(execute(url.toString()), limit) }.getOrDefault(emptyList())
                if (parsed.isNotEmpty()) return@withContext parsed
            }
            emptyList()
        }

    private fun parseEpgResponse(body: String, limit: Int): List<EpgProgram> {
        val root = JSONObject(body)
        val listings = root.optJSONArray("epg_listings")
            ?: root.optJSONArray("listings")
            ?: root.optJSONArray("epg")
            ?: JSONArray()
        return buildList {
            for (index in 0 until minOf(listings.length(), limit.coerceAtLeast(1))) {
                val item = listings.optJSONObject(index) ?: continue
                val start = epgTimestamp(item, "start_timestamp", "start")
                    .takeIf { it > 0L } ?: epgTimestamp(item, "start", "date_start")
                val end = epgTimestamp(item, "stop_timestamp", "end")
                    .takeIf { it > 0L } ?: epgTimestamp(item, "end", "date_end")
                add(
                    EpgProgram(
                        id = item.optString("id", index.toString()),
                        title = decodeEpgText(item.optString("title")).ifBlank {
                            decodeEpgText(item.optString("name")).ifBlank { "Programación sin título" }
                        },
                        description = decodeEpgText(item.optString("description")).ifBlank {
                            decodeEpgText(item.optString("desc"))
                        },
                        startTimestamp = start,
                        endTimestamp = end
                    )
                )
            }
        }.sortedBy { it.startTimestamp }
    }

    private fun decodeEpgText(value: String): String {
        if (value.isBlank()) return ""
        return runCatching {
            String(Base64.getDecoder().decode(value), Charsets.UTF_8)
        }.getOrDefault(value).trim()
    }

    private fun epgTimestamp(item: JSONObject, timestampKey: String, dateKey: String): Long {
        val direct = item.optString(timestampKey).toLongOrNull()
            ?: item.optLong(timestampKey, 0L).takeIf { it > 0L }
        if (direct != null && direct > 0L) return direct
        val dateValue = item.optString(dateKey).ifBlank { item.optString(timestampKey) }
        if (dateValue.isBlank()) return 0L
        val patterns = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm")
        for (pattern in patterns) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.getDefault()).parse(dateValue)?.time?.div(1000L)
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return 0L
    }

    private fun playerApiUrl(baseUrl: String, username: String, password: String) =
        "${baseUrl.trimEnd('/')}/player_api.php".toHttpUrl().newBuilder()
            .addQueryParameter("username", username)
            .addQueryParameter("password", password)

    private fun execute(url: String): String {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "FluxPlay/1.2.1 Android")
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException("Error de conexión ${response.code}: ${body.take(160)}")
            }
            if (body.isBlank()) throw IllegalStateException("El servidor respondió vacío.")
            return body
        }
    }

    private fun formatExpiration(value: String): String {
        val seconds = value.toLongOrNull() ?: return "Sin fecha"
        if (seconds <= 0L) return "Sin fecha"
        return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(seconds * 1000L))
    }
}
