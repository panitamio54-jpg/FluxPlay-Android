package com.fluxplay.app

import android.content.Context

object SessionManager {
    private const val PREFS = "fluxplay_session"

    fun save(context: Context, session: Session) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString("base_url", session.baseUrl)
            .putString("username", session.username)
            .putString("password", session.password)
            .putString("status", session.status)
            .putString("expiration", session.expiration)
            .putString("max_connections", session.maxConnections)
            .putString("active_connections", session.activeConnections)
            .putBoolean("is_trial", session.isTrial)
            .apply()
    }

    fun load(context: Context): Session? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val baseUrl = prefs.getString("base_url", null) ?: return null
        val username = prefs.getString("username", null) ?: return null
        val password = prefs.getString("password", null) ?: return null
        return Session(
            baseUrl = baseUrl,
            username = username,
            password = password,
            status = prefs.getString("status", "Active") ?: "Active",
            expiration = prefs.getString("expiration", "Sin fecha") ?: "Sin fecha",
            maxConnections = prefs.getString("max_connections", "1") ?: "1",
            activeConnections = prefs.getString("active_connections", "0") ?: "0",
            isTrial = prefs.getBoolean("is_trial", false)
        )
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
