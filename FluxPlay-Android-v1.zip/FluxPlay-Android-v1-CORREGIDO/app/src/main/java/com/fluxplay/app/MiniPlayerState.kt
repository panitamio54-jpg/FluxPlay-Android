package com.fluxplay.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Estado compartido dentro del proceso para decidir cuándo debe mostrarse
 * el mini reproductor dentro de FluxPlay.
 */
object MiniPlayerState {
    var visible by mutableStateOf(false)
        private set

    fun show() {
        visible = true
    }

    fun hide() {
        visible = false
    }
}
