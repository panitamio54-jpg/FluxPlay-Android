package com.fluxplay.app

data class AppConfig(
    val service: String,
    val maintenance: Boolean,
    val maintenanceMessage: String,
    val primaryDns: String,
    val backupDns: List<String>,
    val minimumVersion: String,
    val latestVersion: String,
    val updateUrl: String
)

data class Session(
    val baseUrl: String,
    val username: String,
    val password: String,
    val status: String,
    val expiration: String,
    val maxConnections: String,
    val activeConnections: String,
    val isTrial: Boolean
)

enum class CatalogType(
    val title: String,
    val categoryAction: String,
    val contentAction: String,
    val route: String
) {
    LIVE("TV en vivo", "get_live_categories", "get_live_streams", "live"),
    MOVIES("Películas", "get_vod_categories", "get_vod_streams", "movie"),
    SERIES("Series", "get_series_categories", "get_series", "series")
}

data class Category(
    val id: String,
    val name: String
)

data class StreamItem(
    val id: Int,
    val name: String,
    val image: String,
    val categoryId: String,
    val extension: String,
    val description: String,
    val rating: String,
    val hasArchive: Boolean = false,
    val directSource: String = "",
    val epgChannelId: String = ""
)

data class Episode(
    val id: Int,
    val title: String,
    val season: Int,
    val number: Int,
    val extension: String,
    val image: String,
    val description: String
)


data class EpgProgram(
    val id: String,
    val title: String,
    val description: String,
    val startTimestamp: Long,
    val endTimestamp: Long
)
