package com.fluxplay.app

import android.content.Context

/**
 * Favoritos locales por cuenta. Se guardan únicamente los IDs de los canales,
 * por lo que siguen funcionando aunque el catálogo se vuelva a descargar.
 */
object ChannelFavorites {
    private const val PREFS = "fluxplay_channel_favorites"

    private fun accountKey(session: Session): String =
        "${session.baseUrl.trimEnd('/')}|${session.username}".hashCode().toString()

    fun ids(context: Context, session: Session): Set<Int> {
        val stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(accountKey(session), emptySet())
            .orEmpty()
        return stored.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun isFavorite(context: Context, session: Session, channelId: Int): Boolean =
        channelId in ids(context, session)

    fun setFavorite(context: Context, session: Session, channelId: Int, favorite: Boolean): Set<Int> {
        val updated = ids(context, session).toMutableSet()
        if (favorite) updated += channelId else updated -= channelId
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(accountKey(session), updated.map { it.toString() }.toSet())
            .apply()
        return updated
    }

    fun toggle(context: Context, session: Session, channelId: Int): Set<Int> =
        setFavorite(context, session, channelId, !isFavorite(context, session, channelId))
}
