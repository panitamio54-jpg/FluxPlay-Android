package com.fluxplay.app

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("FluxPlay/1.3.1 Android Media3/1.11.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(30_000)
            .setDefaultRequestProperties(
                mapOf(
                    "Accept" to "*/*",
                    "Connection" to "keep-alive",
                    "Icy-MetaData" to "1"
                )
            )

        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)

        // Muchos paneles IPTV entregan MPEG-TS sin AUD o sin keyframes IDR.
        // Media3 puede reproducir el audio pero no llegar a dibujar video si no
        // se habilitan estos flags. Esto hace el parser de TS mucho más tolerante.
        val tsFlags = DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
        val extractorsFactory = DefaultExtractorsFactory()
            .setTsExtractorFlags(tsFlags)

        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory)

        // Arranque rápido para TV en vivo. El valor grande de caché se conserva
        // como techo, pero no obligamos a acumular muchos segundos antes de iniciar.
        val configuredBuffer = AppPreferences.bufferSeconds(this).coerceIn(30, 100)
        val maxBufferSeconds = configuredBuffer.coerceAtMost(45)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                2_000,
                maxBufferSeconds * 1_000,
                500,
                900
            )
            .build()

        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)

        val player = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .build()

        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    private fun stopPlaybackAndNotification() {
        mediaSession?.player?.run {
            pause()
            stop()
            clearMediaItems()
        }
        // Fuerza a Android a quitar el control multimedia de la cortina.
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Al sacar FluxPlay de recientes, se apaga de verdad: sin audio residual
        // y sin tarjeta multimedia pegada en la barra superior.
        stopPlaybackAndNotification()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.run {
                pause()
                stop()
                clearMediaItems()
                release()
            }
            release()
        }
        mediaSession = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
