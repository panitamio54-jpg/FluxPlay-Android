package com.fluxplay.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoSettings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import kotlin.math.roundToInt

private val SettingsBackground = Color(0xFF050B19)
private val SettingsPanel = Color(0xFF151F45)
private val SettingsLine = Color(0xFF2D4B77)
private val SettingsBlue = Color(0xFF398BFF)
private val SettingsMuted = Color(0xFFA9B8CE)

private enum class SettingsModule(val title: String, val icon: ImageVector) {
    GENERAL("Ajustes", Icons.Default.Settings),
    GUIDE("Guía / EPG", Icons.Default.CalendarMonth),
    STREAM_FORMAT("Formato de reproducción", Icons.Default.VideoSettings),
    TIME_FORMAT("Formato de hora", Icons.Default.Language),
    AUTOMATION("Automatización", Icons.Default.AutoMode),
    PARENTAL("Control parental", Icons.Default.Security),
    PLAYER("Elige reproductor", Icons.Default.PlayCircle),
    PLAYER_CONFIG("Configurar reproductor", Icons.Default.Tune),
    EXTERNAL("Reproductores externos", Icons.Default.DisplaySettings),
    MULTI("Pantalla múltiple", Icons.Default.GridView),
    SPEED("Prueba de velocidad", Icons.Default.Speed),
    VPN("VPN", Icons.Default.Lock),
    DEVICE("Cambiar modo de dispositivo", Icons.Default.Devices),
    INFO("Mi información", Icons.Default.Info),
    THEMES("Temas", Icons.Default.Palette)
}

@Composable
fun SettingsScreen(session: Session, onBack: () -> Unit, onLogout: () -> Unit) {
    val context = LocalContext.current
    var selectedModule by remember { mutableStateOf<SettingsModule?>(null) }

    Box(Modifier.fillMaxSize().background(SettingsBackground)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().height(64.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Regresar", tint = Color.White, modifier = Modifier.size(38.dp))
                }
                Spacer(Modifier.width(18.dp))
                Text("AJUSTES", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("FluxPlay", color = SettingsBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(22.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                items(SettingsModule.entries) { module ->
                    SettingsModuleCard(module) {
                        if (module == SettingsModule.VPN) {
                            runCatching {
                                context.startActivity(Intent(AndroidSettings.ACTION_VPN_SETTINGS))
                            }.onFailure {
                                Toast.makeText(context, "No fue posible abrir los ajustes VPN", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            selectedModule = module
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Button(
                    onClick = onLogout,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB42345))
                ) {
                    Icon(Icons.Default.Logout, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Cerrar sesión")
                }
            }
        }
    }

    selectedModule?.let { module ->
        SettingsModuleDialog(
            module = module,
            session = session,
            onDismiss = { selectedModule = null }
        )
    }
}

@Composable
private fun SettingsModuleCard(module: SettingsModule, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(4.dp))
            .background(if (focused) Color(0xFF234A82) else SettingsPanel)
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else SettingsLine, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(module.icon, null, tint = SettingsBlue, modifier = Modifier.size(58.dp))
        Spacer(Modifier.height(15.dp))
        Text(
            module.title,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SettingsModuleDialog(module: SettingsModule, session: Session, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var speedResult by remember { mutableStateOf("Pulsa Iniciar prueba") }
    var testing by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf(AppPreferences.parentalPin(context)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0C1930),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text(module.title, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (module) {
                    SettingsModule.GENERAL -> {
                        SettingInfo("Servidor activo", session.baseUrl)
                        SettingInfo("Estado", session.status)
                        SettingInfo("Versión", BuildConfig.VERSION_NAME)
                    }
                    SettingsModule.GUIDE -> {
                        ToggleLine("Activar guía EPG", AppPreferences.epgEnabled(context)) {
                            AppPreferences.setEpgEnabled(context, it)
                        }
                        Text("FluxPlay consulta get_short_epg y usa una segunda ruta compatible cuando el servidor no responde.", color = SettingsMuted)
                    }
                    SettingsModule.STREAM_FORMAT -> ChoiceList(
                        options = listOf("Automático", "Fuente directa", "HLS (m3u8)", "MPEG-TS"),
                        current = AppPreferences.streamFormat(context),
                        onSelect = { AppPreferences.setStreamFormat(context, it) }
                    )
                    SettingsModule.TIME_FORMAT -> ChoiceList(
                        options = listOf("12 horas", "24 horas"),
                        current = AppPreferences.timeFormat(context),
                        onSelect = { AppPreferences.setTimeFormat(context, it) }
                    )
                    SettingsModule.AUTOMATION -> {
                        ToggleLine("Reproducir automáticamente", AppPreferences.autoplay(context)) {
                            AppPreferences.setAutoplay(context, it)
                        }
                        ToggleLine("Ventana flotante automática", AppPreferences.autoPip(context)) {
                            AppPreferences.setAutoPip(context, it)
                        }
                    }
                    SettingsModule.PARENTAL -> {
                        ToggleLine("Activar control parental", AppPreferences.parentalEnabled(context)) {
                            AppPreferences.setParentalEnabled(context, it)
                        }
                        OutlinedTextField(
                            value = pin,
                            onValueChange = { value -> pin = value.filter(Char::isDigit).take(6) },
                            label = { Text("PIN") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(onClick = {
                            AppPreferences.setParentalPin(context, pin.ifBlank { "0000" })
                            Toast.makeText(context, "PIN guardado", Toast.LENGTH_SHORT).show()
                        }) { Text("Guardar PIN") }
                    }
                    SettingsModule.PLAYER -> ChoiceList(
                        options = listOf("Interno FluxPlay", "Reproductor externo"),
                        current = AppPreferences.playerMode(context),
                        onSelect = { AppPreferences.setPlayerMode(context, it) }
                    )
                    SettingsModule.PLAYER_CONFIG -> {
                        Text("Relación de aspecto", color = SettingsBlue, fontWeight = FontWeight.Bold)
                        ChoiceList(
                            options = listOf("Ajustar", "Rellenar", "Zoom"),
                            current = AppPreferences.aspectMode(context),
                            onSelect = { AppPreferences.setAspectMode(context, it) }
                        )
                        Text("Búfer", color = SettingsBlue, fontWeight = FontWeight.Bold)
                        ChoiceList(
                            options = listOf("Bajo", "Normal", "Alto"),
                            current = AppPreferences.bufferMode(context),
                            onSelect = { AppPreferences.setBufferMode(context, it) }
                        )
                    }
                    SettingsModule.EXTERNAL -> ChoiceList(
                        options = listOf("Preguntar siempre", "VLC", "MX Player"),
                        current = AppPreferences.externalPlayer(context),
                        onSelect = { AppPreferences.setExternalPlayer(context, it) }
                    )
                    SettingsModule.MULTI -> ToggleLine("Permitir pantalla múltiple", AppPreferences.multiScreen(context)) {
                        AppPreferences.setMultiScreen(context, it)
                    }
                    SettingsModule.SPEED -> {
                        Text(speedResult, color = if (testing) SettingsMuted else Color.White, fontSize = 20.sp)
                        Button(
                            enabled = !testing,
                            onClick = {
                                testing = true
                                speedResult = "Midiendo…"
                                scope.launch {
                                    speedResult = runSpeedTest()
                                    testing = false
                                }
                            }
                        ) { Text("Iniciar prueba") }
                    }
                    SettingsModule.VPN -> Unit
                    SettingsModule.DEVICE -> ChoiceList(
                        options = listOf("Automático", "Televisor / TV Box", "Teléfono / Tableta"),
                        current = AppPreferences.deviceMode(context),
                        onSelect = { AppPreferences.setDeviceMode(context, it) }
                    )
                    SettingsModule.INFO -> {
                        SettingInfo("Usuario", session.username)
                        SettingInfo("Vencimiento", session.expiration)
                        SettingInfo("Conexiones", "${session.activeConnections} de ${session.maxConnections}")
                        SettingInfo("Cuenta", if (session.isTrial) "Prueba" else "Normal")
                    }
                    SettingsModule.THEMES -> ChoiceList(
                        options = listOf("Azul noche", "Morado neón", "Esmeralda", "Rojo cinema", "Negro OLED"),
                        current = AppPreferences.theme(context),
                        onSelect = {
                            AppPreferences.setTheme(context, it)
                            Toast.makeText(context, "Tema aplicado", Toast.LENGTH_SHORT).show()
                            (context as? Activity)?.recreate()
                        }
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun SettingInfo(label: String, value: String) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF111F39), RoundedCornerShape(10.dp)).padding(11.dp)) {
        Text(label, color = SettingsMuted, fontSize = 12.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ToggleLine(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    var checked by remember(label) { mutableStateOf(value) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = {
            checked = it
            onChange(it)
        })
    }
}

@Composable
private fun ChoiceList(options: List<String>, current: String, onSelect: (String) -> Unit) {
    var selected by remember(options, current) { mutableStateOf(current) }
    options.forEach { option ->
        Row(
            Modifier.fillMaxWidth().clickable {
                selected = option
                onSelect(option)
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected == option, onClick = {
                selected = option
                onSelect(option)
            })
            Text(option, color = Color.White)
        }
    }
}

private suspend fun runSpeedTest(): String = withContext(Dispatchers.IO) {
    runCatching {
        val started = System.nanoTime()
        val bytes = URL("https://speed.cloudflare.com/__down?bytes=2000000").openStream().use { input ->
            val buffer = ByteArray(32 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
            }
            total
        }
        val seconds = (System.nanoTime() - started) / 1_000_000_000.0
        val mbps = (bytes * 8.0 / 1_000_000.0) / seconds.coerceAtLeast(0.1)
        "${(mbps * 10).roundToInt() / 10.0} Mbps"
    }.getOrElse { "No fue posible medir la velocidad" }
}
