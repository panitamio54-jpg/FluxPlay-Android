package com.fluxplay.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val FluxBlue = Color(0xFF198BFF)
private val FluxPurple = Color(0xFF7438FF)
private val FluxOrange = Color(0xFFFF7A28)
private val FluxBackground = Color(0xFF050B19)
private val FluxPanel = Color(0xD90B162B)
private val FluxLine = Color(0xFF243A5E)
private val FluxTextMuted = Color(0xFF9EB2CF)
private const val FAVORITES_SECTION = "__flux_favorites__"
private const val RECENT_SECTION = "__flux_recent__"

private sealed interface AppScreen {
    data object Splash : AppScreen
    data object Login : AppScreen
    data object Dashboard : AppScreen
    data class Catalog(val type: CatalogType, val initialSection: String = "") : AppScreen
    data class SeriesDetail(val series: StreamItem) : AppScreen
    data class Placeholder(val title: String, val message: String) : AppScreen
    data object Settings : AppScreen
}

class MainActivity : ComponentActivity() {
    override fun onDestroy() {
        if (isFinishing) {
            stopService(Intent(this, PlaybackService::class.java))
            MiniPlayerState.hide()
        }
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = FluxBlue,
                    secondary = FluxPurple,
                    background = FluxBackground,
                    surface = FluxPanel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                FluxPlayApplication()
            }
        }
    }
}

@Composable
private fun FluxPlayApplication() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf<AppScreen>(AppScreen.Splash) }
    var session by remember { mutableStateOf<Session?>(null) }
    var startupError by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        delay(2_000)
        val stored = SessionManager.load(context)
        if (stored == null) {
            screen = AppScreen.Login
            return@LaunchedEffect
        }
        try {
            val config = ApiClient.fetchConfig()
            if (config.maintenance) {
                startupError = config.maintenanceMessage.ifBlank { "Servicio temporalmente en mantenimiento." }
                screen = AppScreen.Login
                return@LaunchedEffect
            }
            val renewed = authenticateUsingConfig(config, stored.username, stored.password)
            SessionManager.save(context, renewed)
            session = renewed
            screen = AppScreen.Dashboard
        } catch (error: Exception) {
            SessionManager.clear(context)
            startupError = "Vuelve a iniciar sesión. ${error.message.orEmpty()}".trim()
            screen = AppScreen.Login
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = FluxBackground) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (val destination = screen) {
            AppScreen.Splash -> SplashScreen()
            AppScreen.Login -> LoginScreen(
                initialError = startupError,
                onLogin = { newSession ->
                    session = newSession
                    SessionManager.save(context, newSession)
                    startupError = ""
                    screen = AppScreen.Dashboard
                }
            )
            AppScreen.Dashboard -> session?.let { activeSession ->
                DashboardScreen(
                    session = activeSession,
                    onOpen = { screen = it },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
            is AppScreen.Catalog -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                CatalogScreen(
                    session = activeSession,
                    type = destination.type,
                    initialSection = destination.initialSection,
                    onBack = { screen = AppScreen.Dashboard },
                    onSeries = { screen = AppScreen.SeriesDetail(it) }
                )
            }
            is AppScreen.SeriesDetail -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Catalog(CatalogType.SERIES) }
                SeriesDetailScreen(
                    session = activeSession,
                    series = destination.series,
                    onBack = { screen = AppScreen.Catalog(CatalogType.SERIES) }
                )
            }
            is AppScreen.Placeholder -> {
                BackHandler { screen = AppScreen.Dashboard }
                PlaceholderScreen(destination.title, destination.message) {
                    screen = AppScreen.Dashboard
                }
            }
            AppScreen.Settings -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                SettingsScreen(
                    session = activeSession,
                    onBack = { screen = AppScreen.Dashboard },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
            }
            if (screen != AppScreen.Splash && screen != AppScreen.Login) {
                MiniPlayerOverlay()
            }
        }
    }
}

private suspend fun authenticateUsingConfig(config: AppConfig, username: String, password: String): Session {
    var lastError: Exception? = null
    for (dns in listOf(config.primaryDns) + config.backupDns) {
        try {
            return ApiClient.authenticate(dns, username, password)
        } catch (error: Exception) {
            lastError = error
        }
    }
    throw lastError ?: IllegalStateException("No fue posible conectar con los servidores configurados.")
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier.fillMaxWidth(0.72f),
            contentScale = ContentScale.Fit
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginScreen(initialError: String, onLogin: (Session) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember(initialError) { mutableStateOf(initialError) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    BrandedBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // Los teléfonos en horizontal tienen bastante ancho, pero muy poca altura.
            // Se adapta por altura para que el botón Entrar nunca quede fuera de pantalla.
            val shortScreen = maxHeight < 540.dp
            val narrowScreen = maxWidth < 700.dp
            val outerPadding = if (shortScreen) 12.dp else if (narrowScreen) 20.dp else 46.dp
            val panelPadding = if (shortScreen) 16.dp else 30.dp
            val itemSpacing = if (shortScreen) 8.dp else 16.dp

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .padding(outerPadding),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!narrowScreen) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (shortScreen) 190.dp else 310.dp),
                            contentScale = ContentScale.Fit
                        )
                        if (!shortScreen) {
                            Text(
                                "Tu entretenimiento, conectado siempre.",
                                color = FluxTextMuted,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(start = 34.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(if (shortScreen) 18.dp else 36.dp))
                }

                Column(
                    modifier = Modifier
                        .then(
                            when {
                                shortScreen && !narrowScreen -> Modifier
                                    .widthIn(min = 390.dp, max = 520.dp)
                                    .fillMaxHeight()
                                narrowScreen -> Modifier.fillMaxWidth()
                                else -> Modifier.width(430.dp)
                            }
                        )
                        .clip(RoundedCornerShape(if (shortScreen) 22.dp else 28.dp))
                        .background(FluxPanel)
                        .border(
                            1.dp,
                            FluxLine,
                            RoundedCornerShape(if (shortScreen) 22.dp else 28.dp)
                        )
                        .verticalScroll(rememberScrollState())
                        .padding(panelPadding),
                    verticalArrangement = Arrangement.spacedBy(itemSpacing)
                ) {
                    if (narrowScreen && !shortScreen) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Text(
                        "Iniciar sesión",
                        fontSize = if (shortScreen) 25.sp else 30.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "Ingresa el usuario y la contraseña entregados por tu proveedor.",
                        color = FluxTextMuted,
                        fontSize = if (shortScreen) 14.sp else 16.sp,
                        maxLines = if (shortScreen) 2 else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.trim() },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Usuario") },
                        leadingIcon = { Icon(Icons.Default.Person, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Contraseña") },
                        leadingIcon = { Icon(Icons.Default.Lock, null) },
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (errorMessage.isNotBlank()) {
                        Text(
                            errorMessage,
                            color = Color(0xFFFF8EA1),
                            fontSize = if (shortScreen) 12.sp else 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x332B0010))
                                .padding(if (shortScreen) 8.dp else 12.dp)
                        )
                    }
                    Button(
                        onClick = {
                            if (username.isBlank() || password.isBlank()) {
                                errorMessage = "Escribe el usuario y la contraseña."
                                return@Button
                            }
                            scope.launch {
                                loading = true
                                errorMessage = ""
                                try {
                                    val config = ApiClient.fetchConfig()
                                    if (config.maintenance) {
                                        throw IllegalStateException(
                                            config.maintenanceMessage.ifBlank { "Servicio en mantenimiento." }
                                        )
                                    }
                                    onLogin(authenticateUsingConfig(config, username, password))
                                } catch (error: Exception) {
                                    errorMessage = error.message ?: "No fue posible iniciar sesión."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (shortScreen) 50.dp else 58.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FluxBlue),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(25.dp),
                                strokeWidth = 3.dp
                            )
                        } else {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Entrar a FluxPlay",
                                fontSize = if (shortScreen) 15.sp else 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (!shortScreen) {
                        Text(
                            "La DNS se obtiene automáticamente desde FluxPlay Control.",
                            color = FluxTextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    session: Session,
    onOpen: (AppScreen) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var liveItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var movieItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var seriesItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var homeAds by remember { mutableStateOf<List<HomeAd>>(emptyList()) }
    var activeAdIndex by remember { mutableStateOf(0) }
    var adRotationSeconds by remember { mutableStateOf(3) }
    var loadingLive by remember { mutableStateOf(true) }
    var loadingMovies by remember { mutableStateOf(true) }
    var loadingSeries by remember { mutableStateOf(true) }
    var countError by remember { mutableStateOf("") }
    var refreshingLive by remember { mutableStateOf(false) }
    var refreshingMovies by remember { mutableStateOf(false) }
    var refreshingSeries by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    suspend fun refreshDashboardCatalog(type: CatalogType) {
        when (type) {
            CatalogType.LIVE -> refreshingLive = true
            CatalogType.MOVIES -> refreshingMovies = true
            CatalogType.SERIES -> refreshingSeries = true
        }
        try {
            val freshCategories = ApiClient.fetchCategories(session, type)
            if (freshCategories.isNotEmpty()) {
                CatalogCache.saveCategories(context, session, type, freshCategories)
            }
            val freshItems = ApiClient.fetchCatalogItems(session, type, freshCategories)
            if (freshItems.isNotEmpty()) {
                CatalogCache.saveItems(context, session, type, freshItems)
                when (type) {
                    CatalogType.LIVE -> liveItems = freshItems
                    CatalogType.MOVIES -> movieItems = freshItems
                    CatalogType.SERIES -> seriesItems = freshItems
                }
                countError = ""
            } else {
                countError = "No se encontró contenido nuevo para ${type.title}."
            }
        } catch (exception: Exception) {
            countError = "No se pudo actualizar ${type.title}: ${exception.message.orEmpty()}"
        } finally {
            when (type) {
                CatalogType.LIVE -> refreshingLive = false
                CatalogType.MOVIES -> refreshingMovies = false
                CatalogType.SERIES -> refreshingSeries = false
            }
        }
    }

    LaunchedEffect(session.baseUrl, session.username) {
        countError = ""

        // 1) Primero la caché local. No esperamos a ninguna llamada de red para
        // pintar canales, películas o series que ya se descargaron anteriormente.
        coroutineScope {
            val cachedLive = async { CatalogCache.loadItems(context, session, CatalogType.LIVE) }
            val cachedMovies = async { CatalogCache.loadItems(context, session, CatalogType.MOVIES) }
            val cachedSeries = async { CatalogCache.loadItems(context, session, CatalogType.SERIES) }
            cachedLive.await()?.let { liveItems = it }
            cachedMovies.await()?.let { movieItems = it }
            cachedSeries.await()?.let { seriesItems = it }
        }

        loadingLive = liveItems.isEmpty()
        loadingMovies = movieItems.isEmpty()
        loadingSeries = seriesItems.isEmpty()

        // La publicidad/configuración se actualiza aparte y nunca bloquea el catálogo.
        launch {
            runCatching { ApiClient.fetchConfig() }
                .onSuccess { config ->
                    homeAds = config.homeAds
                    adRotationSeconds = config.adRotationSeconds
                    activeAdIndex = 0
                }
        }

        // 2) Si existe caché, no volvemos a descargar automáticamente decenas de
        // miles de títulos al entrar. El botón de actualizar de cada tarjeta fuerza
        // la sincronización cuando el usuario quiera contenido nuevo.
        coroutineScope {
            if (liveItems.isEmpty()) {
                launch {
                    runCatching { ApiClient.fetchCatalogItems(session, CatalogType.LIVE, emptyList()) }
                        .onSuccess { fresh ->
                            if (fresh.isNotEmpty()) {
                                liveItems = fresh
                                CatalogCache.saveItems(context, session, CatalogType.LIVE, fresh)
                            }
                        }
                        .onFailure { countError = "TV: ${it.message.orEmpty()}" }
                    loadingLive = false
                }
            }

            if (movieItems.isEmpty()) {
                launch {
                    runCatching {
                        val categories = ApiClient.fetchCategories(session, CatalogType.MOVIES)
                        if (categories.isNotEmpty()) CatalogCache.saveCategories(context, session, CatalogType.MOVIES, categories)
                        ApiClient.fetchCatalogItems(session, CatalogType.MOVIES, categories)
                    }.onSuccess { fresh ->
                        if (fresh.isNotEmpty()) {
                            movieItems = fresh
                            CatalogCache.saveItems(context, session, CatalogType.MOVIES, fresh)
                        }
                    }.onFailure { countError = "Películas: ${it.message.orEmpty()}" }
                    loadingMovies = false
                }
            }

            if (seriesItems.isEmpty()) {
                launch {
                    runCatching {
                        val categories = ApiClient.fetchCategories(session, CatalogType.SERIES)
                        if (categories.isNotEmpty()) CatalogCache.saveCategories(context, session, CatalogType.SERIES, categories)
                        ApiClient.fetchCatalogItems(session, CatalogType.SERIES, categories)
                    }.onSuccess { fresh ->
                        if (fresh.isNotEmpty()) {
                            seriesItems = fresh
                            CatalogCache.saveItems(context, session, CatalogType.SERIES, fresh)
                        }
                    }.onFailure { countError = "Series: ${it.message.orEmpty()}" }
                    loadingSeries = false
                }
            }
        }
    }

    LaunchedEffect(homeAds, adRotationSeconds) {
        activeAdIndex = 0
        if (homeAds.size > 1) {
            while (true) {
                delay(adRotationSeconds.coerceAtLeast(3) * 1_000L)
                activeAdIndex = (activeAdIndex + 1) % homeAds.size
            }
        }
    }

    val activeHomeAd = homeAds.getOrNull(activeAdIndex)

    val featuredMovie = remember(movieItems) {
        movieItems.firstOrNull { it.image.isNotBlank() } ?: movieItems.firstOrNull()
    }

    BrandedBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxHeight < 560.dp || maxWidth < 1_080.dp
            val outerPadding = if (compact) 10.dp else 18.dp
            val gap = if (compact) 9.dp else 14.dp

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(outerPadding)
            ) {
                Sidebar(
                    compact = compact,
                    selected = "Inicio",
                    onHome = {},
                    onLive = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) },
                    onMovies = { onOpen(AppScreen.Catalog(CatalogType.MOVIES)) },
                    onSeries = { onOpen(AppScreen.Catalog(CatalogType.SERIES)) },
                    onGuide = { onOpen(AppScreen.Placeholder("TV Guide", "La guía completa se conectará al EPG del proveedor.")) },
                    onCatchUp = { onOpen(AppScreen.Placeholder("Catch Up", "Aquí aparecerán los canales que tengan programación grabada.")) },
                    onFavorites = { onOpen(AppScreen.Catalog(CatalogType.LIVE, FAVORITES_SECTION)) },
                    onSettings = { onOpen(AppScreen.Settings) }
                )

                Spacer(Modifier.width(gap))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    HeaderBar(compact)
                    Spacer(Modifier.height(gap))

                    if (countError.isNotBlank()) {
                        Text(
                            "No se pudieron actualizar algunos datos: $countError",
                            color = Color(0xFFFFB0BC),
                            fontSize = if (compact) 10.sp else 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(5.dp))
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(2.15f)
                                .fillMaxHeight()
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1.08f)
                                    .fillMaxWidth()
                            ) {
                                DashboardHeroCard(
                                    compact = compact,
                                    title = "LIVE TV",
                                    subtitle = if (loadingLive) "Cargando canales…" else "${liveItems.size} canales disponibles",
                                    imageUrl = liveItems.firstOrNull { it.image.isNotBlank() }?.image.orEmpty(),
                                    icon = Icons.Default.LiveTv,
                                    accent = FluxBlue,
                                    modifier = Modifier
                                        .weight(1.38f)
                                        .fillMaxHeight(),
                                    refreshing = refreshingLive,
                                    onRefresh = { scope.launch { refreshDashboardCatalog(CatalogType.LIVE) } },
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "MOVIES",
                                    subtitle = if (loadingMovies) "Cargando películas…" else "${movieItems.size} películas a tu alcance",
                                    imageUrl = featuredMovie?.image.orEmpty(),
                                    icon = Icons.Default.Movie,
                                    colors = listOf(Color(0xCC151B2B), Color(0xE60A0E18)),
                                    modifier = Modifier
                                        .weight(0.82f)
                                        .fillMaxHeight(),
                                    refreshing = refreshingMovies,
                                    onRefresh = { scope.launch { refreshDashboardCatalog(CatalogType.MOVIES) } },
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.MOVIES)) }
                                )
                            }

                            Spacer(Modifier.height(gap))

                            Row(
                                modifier = Modifier
                                    .weight(0.92f)
                                    .fillMaxWidth()
                            ) {
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "SERIES",
                                    subtitle = if (loadingSeries) "Cargando series…" else "${seriesItems.size} series disponibles",
                                    imageUrl = seriesItems.firstOrNull { it.image.isNotBlank() }?.image.orEmpty(),
                                    icon = Icons.Default.VideoLibrary,
                                    colors = listOf(Color(0xCC311C2D), Color(0xED10101B)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    refreshing = refreshingSeries,
                                    onRefresh = { scope.launch { refreshDashboardCatalog(CatalogType.SERIES) } },
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.SERIES)) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "TV GUIDE",
                                    subtitle = "Consulta la programación de tus canales",
                                    imageUrl = "",
                                    icon = Icons.Default.CalendarMonth,
                                    colors = listOf(Color(0xD530267B), Color(0xEB111329)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Placeholder("TV Guide", "La guía completa se conectará al EPG del proveedor.")) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "CATCH UP",
                                    subtitle = "Mira nuevamente lo que te perdiste",
                                    imageUrl = "",
                                    icon = Icons.Default.History,
                                    colors = listOf(Color(0xD2075963), Color(0xEB081C26)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Placeholder("Catch Up", "Aquí aparecerán los canales que tengan programación grabada.")) }
                                )
                            }
                        }

                        Spacer(Modifier.width(gap))

                        FeaturedDashboardCard(
                            compact = compact,
                            item = featuredMovie,
                            ad = activeHomeAd,
                            modifier = Modifier
                                .weight(0.92f)
                                .fillMaxHeight(),
                            onClick = {
                                val activeAd = activeHomeAd
                                if (activeAd != null) {
                                    when (activeAd.actionType) {
                                        "live" -> onOpen(AppScreen.Catalog(CatalogType.LIVE))
                                        "movies" -> onOpen(AppScreen.Catalog(CatalogType.MOVIES))
                                        "series" -> onOpen(AppScreen.Catalog(CatalogType.SERIES))
                                        "url" -> if (activeAd.actionUrl.isNotBlank()) {
                                            runCatching {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(activeAd.actionUrl)))
                                            }
                                        }
                                        else -> Unit
                                    }
                                } else {
                                    val item = featuredMovie
                                    if (item != null) {
                                        openPlayer(context, session, CatalogType.MOVIES, item.id, item.extension, item.name, item.directSource)
                                    } else {
                                        onOpen(AppScreen.Catalog(CatalogType.MOVIES))
                                    }
                                }
                            }
                        )
                    }

                    Spacer(Modifier.height(gap))
                    StatusBar(session = session, compact = compact, onLogout = onLogout)
                }
            }
        }
    }
}

@Composable
private fun HeaderBar(compact: Boolean) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }
    val timePattern = if (AppPreferences.timeFormat(context) == "24 horas") "HH:mm" else "hh:mm a"
    val time = remember(now, timePattern) { SimpleDateFormat(timePattern, Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(now) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 50.dp else 66.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Tu entretenimiento, en un solo lugar",
            color = FluxTextMuted,
            fontSize = if (compact) 11.sp else 14.sp,
            maxLines = 1
        )
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                time,
                fontSize = if (compact) 19.sp else 25.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
            Text(
                date,
                color = FluxTextMuted,
                fontSize = if (compact) 11.sp else 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Sidebar(
    compact: Boolean,
    selected: String,
    onHome: () -> Unit,
    onLive: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onGuide: () -> Unit,
    onCatchUp: () -> Unit,
    onFavorites: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(if (compact) 145.dp else 184.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(if (compact) 20.dp else 26.dp))
            .background(Color(0xDD030B18))
            .border(1.dp, Color(0x663D6DA8), RoundedCornerShape(if (compact) 20.dp else 26.dp))
            .padding(horizontal = if (compact) 8.dp else 13.dp, vertical = if (compact) 8.dp else 13.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 6.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 48.dp else 68.dp),
            contentScale = ContentScale.Fit
        )
        NavButton("Inicio", Icons.Default.Home, selected == "Inicio", compact, onHome)
        NavButton("Live TV", Icons.Default.LiveTv, selected == "Live TV", compact, onLive)
        NavButton("Películas", Icons.Default.Movie, selected == "Películas", compact, onMovies)
        NavButton("Series", Icons.Default.VideoLibrary, selected == "Series", compact, onSeries)
        NavButton("Guía TV", Icons.Default.CalendarMonth, selected == "Guía TV", compact, onGuide)
        NavButton("Catch Up", Icons.Default.History, selected == "Catch Up", compact, onCatchUp)
        NavButton("Favoritos", Icons.Default.FavoriteBorder, selected == "Favoritos", compact, onFavorites)
        if (compact) Spacer(Modifier.height(2.dp)) else Spacer(Modifier.weight(1f))
        NavButton("Ajustes", Icons.Default.Settings, selected == "Ajustes", compact, onSettings)
        if (compact) Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun NavButton(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val background by animateColorAsState(
        if (selected || focused) Color(0xFF0E4D98) else Color.Transparent,
        label = "nav-background"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(if (compact) 11.dp else 15.dp))
            .background(background)
            .then(
                if (focused) Modifier.border(
                    2.dp,
                    Color(0xFF59B4FF),
                    RoundedCornerShape(if (compact) 11.dp else 15.dp)
                ) else Modifier
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(
                horizontal = if (compact) 9.dp else 13.dp,
                vertical = if (compact) 6.dp else 10.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            null,
            tint = if (selected || focused) Color.White else FluxTextMuted,
            modifier = Modifier.size(if (compact) 19.dp else 23.dp)
        )
        Spacer(Modifier.width(if (compact) 8.dp else 11.dp))
        Text(
            label,
            fontSize = if (compact) 11.sp else 14.sp,
            fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun DashboardHeroCard(
    compact: Boolean,
    title: String,
    subtitle: String,
    imageUrl: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier,
    refreshing: Boolean = false,
    onRefresh: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 18.dp else 25.dp)
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color(0xFF0D2B57))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else Color(0x995D8BC4), shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.24f
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xF00A4EA4), Color(0xD70B1732), Color(0xF0050C18))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 14.dp else 21.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFFF385C)))
                Spacer(Modifier.width(7.dp))
                Text("En vivo ahora", fontSize = if (compact) 10.sp else 12.sp)
                Spacer(Modifier.weight(1f))
                Icon(icon, null, tint = accent, modifier = Modifier.size(if (compact) 27.dp else 35.dp))
            }
            Column {
                Text(
                    title,
                    fontSize = if (compact) 27.sp else 38.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    subtitle,
                    color = Color(0xFFD8E7FB),
                    fontSize = if (compact) 11.sp else 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
                Text(
                    "Explorar canales   ›",
                    color = Color.White,
                    fontSize = if (compact) 11.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (focused) FluxBlue else Color(0xA61765C1))
                        .padding(horizontal = if (compact) 11.dp else 15.dp, vertical = if (compact) 6.dp else 9.dp)
                )
            }
        }
        if (onRefresh != null) {
            IconButton(
                onClick = onRefresh,
                enabled = !refreshing,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(if (compact) 8.dp else 12.dp)
                    .size(if (compact) 34.dp else 42.dp)
                    .clip(RoundedCornerShape(if (compact) 9.dp else 11.dp))
                    .background(Color(0xF2FFFFFF))
            ) {
                if (refreshing) {
                    CircularProgressIndicator(
                        color = FluxBlue,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(if (compact) 17.dp else 21.dp)
                    )
                } else {
                    Icon(
                        Icons.Default.Refresh,
                        "Actualizar contenido",
                        tint = Color(0xFF07111F),
                        modifier = Modifier.size(if (compact) 20.dp else 24.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardSmallCard(
    compact: Boolean,
    title: String,
    subtitle: String,
    imageUrl: String,
    icon: ImageVector,
    colors: List<Color>,
    modifier: Modifier,
    refreshing: Boolean = false,
    onRefresh: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 17.dp else 23.dp)
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(colors.last())
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else FluxLine, shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.46f
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors)))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 12.dp else 18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, modifier = Modifier.size(if (compact) 24.dp else 31.dp), tint = Color.White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.PlayArrow, null, tint = if (focused) FluxOrange else Color.White)
            }
            Column {
                Text(
                    title,
                    fontSize = if (compact) 19.sp else 27.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    subtitle,
                    color = Color(0xFFD3DBE9),
                    fontSize = if (compact) 10.sp else 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(if (compact) 5.dp else 8.dp))
                Text(
                    "Explorar  ›",
                    fontSize = if (compact) 10.sp else 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (focused) Color.White else Color(0xFFC2D7F4)
                )
            }
        }
        if (onRefresh != null) {
            IconButton(
                onClick = onRefresh,
                enabled = !refreshing,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(if (compact) 7.dp else 10.dp)
                    .size(if (compact) 32.dp else 39.dp)
                    .clip(RoundedCornerShape(if (compact) 8.dp else 10.dp))
                    .background(Color(0xF2FFFFFF))
            ) {
                if (refreshing) {
                    CircularProgressIndicator(
                        color = FluxBlue,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(if (compact) 16.dp else 20.dp)
                    )
                } else {
                    Icon(
                        Icons.Default.Refresh,
                        "Actualizar contenido",
                        tint = Color(0xFF07111F),
                        modifier = Modifier.size(if (compact) 19.dp else 23.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FeaturedDashboardCard(
    compact: Boolean,
    item: StreamItem?,
    ad: HomeAd?,
    modifier: Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 18.dp else 25.dp)
    val hasAd = ad?.enabled == true && ad.imageUrl.isNotBlank()
    val imageUrl = if (hasAd) ad?.imageUrl.orEmpty() else item?.image.orEmpty()
    val title = if (hasAd) ad?.title.orEmpty().ifBlank { "Publicidad FluxPlay" } else item?.name ?: "Explora todo el catálogo"
    val subtitle = if (hasAd) ad?.subtitle.orEmpty().ifBlank { "Contenido destacado" } else "FluxPlay recomendado"
    val badge = if (hasAd) ad?.badge.orEmpty().ifBlank { "PUBLICIDAD" } else "★ DESTACADO"
    val tag = if (hasAd) ad?.tag.orEmpty() else "NUEVO"
    val button = if (hasAd) ad?.buttonText.orEmpty().ifBlank { "Ver ahora" } else "Ver ahora"
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color(0xFF101827))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Image(
                painter = painterResource(R.drawable.flux_background),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x22000000), Color(0x55000000), Color(0xF2050A14))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 14.dp else 20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    badge,
                    fontSize = if (compact) 9.sp else 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x99061120))
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                )
                Spacer(Modifier.weight(1f))
                if (tag.isNotBlank()) {
                    Text(
                        tag,
                        fontSize = if (compact) 9.sp else 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFE83259))
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }
            Column {
                Text(subtitle, color = Color(0xFFC8D4E5), fontSize = if (compact) 10.sp else 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    title,
                    fontSize = if (compact) 20.sp else 28.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (!hasAd && !item?.rating.isNullOrBlank()) {
                    Text("★ ${item?.rating}", color = Color(0xFFFFD166), fontSize = if (compact) 10.sp else 12.sp)
                }
                Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
                Row {
                    Text(
                        "▶  $button",
                        fontSize = if (compact) 10.sp else 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (focused) FluxBlue else Color(0xCC125DB8))
                            .padding(horizontal = if (compact) 11.dp else 15.dp, vertical = if (compact) 7.dp else 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBar(session: Session, compact: Boolean, onLogout: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 43.dp else 56.dp)
            .clip(RoundedCornerShape(if (compact) 14.dp else 18.dp))
            .background(Color(0xE5091529))
            .border(1.dp, FluxLine, RoundedCornerShape(if (compact) 14.dp else 18.dp))
            .padding(horizontal = if (compact) 13.dp else 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Lock, null, tint = FluxBlue, modifier = Modifier.size(if (compact) 16.dp else 20.dp))
        Spacer(Modifier.width(7.dp))
        Text("EXPIRACIÓN:", color = Color(0xFF55B9FF), fontSize = if (compact) 10.sp else 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(7.dp))
        Text(session.expiration, fontSize = if (compact) 11.sp else 14.sp, maxLines = 1)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF31E58B)))
        Spacer(Modifier.width(7.dp))
        Text("Conectado:", color = FluxTextMuted, fontSize = if (compact) 10.sp else 13.sp)
        Spacer(Modifier.width(5.dp))
        Text(session.username, fontSize = if (compact) 11.sp else 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.width(if (compact) 5.dp else 10.dp))
        IconButton(onClick = onLogout, modifier = Modifier.size(if (compact) 31.dp else 40.dp)) {
            Icon(Icons.Default.Logout, "Cerrar sesión", modifier = Modifier.size(if (compact) 17.dp else 21.dp))
        }
    }
}

@Composable
private fun CatalogScreen(
    session: Session,
    type: CatalogType,
    initialSection: String = "",
    onBack: () -> Unit,
    onSeries: (StreamItem) -> Unit
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var content by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var selectedCategory by remember(type, initialSection) { mutableStateOf(initialSection) }
    var searchQuery by remember(type) { mutableStateOf("") }
    var searchVisible by remember(type) { mutableStateOf(false) }
    var favoriteChannelIds by remember(session.baseUrl, session.username) {
        mutableStateOf(ChannelFavorites.ids(context, session))
    }
    val scope = rememberCoroutineScope()

    suspend fun reload(forceNetwork: Boolean = false) {
        error = ""

        if (!forceNetwork) {
            coroutineScope {
                val cachedCategories = async { CatalogCache.loadCategories(context, session, type) }
                val cachedContent = async { CatalogCache.loadItems(context, session, type) }
                cachedCategories.await()?.let { categories = it }
                cachedContent.await()?.let { content = it }
            }

            if (content.isNotEmpty()) {
                if (categories.isEmpty()) {
                    runCatching { ApiClient.fetchCategories(session, type) }
                        .getOrNull()
                        ?.takeIf { it.isNotEmpty() }
                        ?.let {
                            categories = it
                            CatalogCache.saveCategories(context, session, type, it)
                        }
                }
                loading = false
                return
            }
        }

        loading = true
        try {
            val freshCategories = ApiClient.fetchCategories(session, type)
            if (freshCategories.isNotEmpty()) {
                categories = freshCategories
                CatalogCache.saveCategories(context, session, type, freshCategories)
            }

            val effectiveCategories = freshCategories.ifEmpty { categories }
            val freshContent = ApiClient.fetchCatalogItems(session, type, effectiveCategories)
            if (freshContent.isNotEmpty()) {
                content = freshContent
                CatalogCache.saveItems(context, session, type, freshContent)
            } else if (content.isEmpty()) {
                error = "El servidor devolvió las categorías, pero no entregó contenido. Pulsa actualizar para reintentar."
            }
        } catch (exception: Exception) {
            if (content.isEmpty()) {
                error = exception.message ?: "No fue posible cargar el contenido."
            }
        } finally {
            loading = false
        }
    }

    LaunchedEffect(type, session.baseUrl, session.username) { reload() }

    val recentlyAdded = remember(content, type) {
        if (type == CatalogType.LIVE) emptyList() else {
            content
                .sortedWith(
                    compareByDescending<StreamItem> { it.addedTimestamp > 0L }
                        .thenByDescending { if (it.addedTimestamp > 0L) it.addedTimestamp else it.id.toLong() }
                )
                .take(120)
        }
    }
    val recentIds = remember(recentlyAdded) { recentlyAdded.mapTo(hashSetOf()) { it.id } }

    val filtered = remember(content, selectedCategory, searchQuery, favoriteChannelIds, recentIds) {
        content.filter { item ->
            val matchesSection = when (selectedCategory) {
                FAVORITES_SECTION -> type == CatalogType.LIVE && item.id in favoriteChannelIds
                RECENT_SECTION -> type != CatalogType.LIVE && item.id in recentIds
                "" -> true
                else -> item.categoryId == selectedCategory
            }
            val matchesSearch = searchQuery.isBlank() || item.name.contains(searchQuery.trim(), ignoreCase = true)
            matchesSection && matchesSearch
        }.let { items ->
            if (selectedCategory == RECENT_SECTION) {
                items.sortedWith(
                    compareByDescending<StreamItem> { it.addedTimestamp > 0L }
                        .thenByDescending { if (it.addedTimestamp > 0L) it.addedTimestamp else it.id.toLong() }
                )
            } else items
        }
    }

    val searchPlaceholder = remember(type) {
        when (type) {
            CatalogType.LIVE -> "Buscar canal…"
            CatalogType.MOVIES -> "Buscar película…"
            CatalogType.SERIES -> "Buscar serie…"
        }
    }
    val selectedTitle = remember(categories, selectedCategory, type) {
        when (selectedCategory) {
            FAVORITES_SECTION -> "Canales favoritos"
            RECENT_SECTION -> if (type == CatalogType.MOVIES) {
                "Películas añadidas recientemente"
            } else {
                "Series añadidas recientemente"
            }
            else -> categories.firstOrNull { it.id == selectedCategory }?.name ?: type.title
        }
    }

    BrandedBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxHeight < 520.dp
            val sidebarWidth = if (maxWidth < 1050.dp) 245.dp else 305.dp
            val pagePadding = if (compact) 12.dp else 18.dp

            Column(Modifier.fillMaxSize().padding(pagePadding)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.size(if (compact) 42.dp else 48.dp)) {
                        Icon(Icons.Default.ArrowBack, "Regresar", modifier = Modifier.size(if (compact) 28.dp else 34.dp))
                    }
                    Spacer(Modifier.width(8.dp))

                    if (searchVisible) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = {
                                Text(
                                    searchPlaceholder,
                                    color = FluxTextMuted,
                                    fontSize = if (compact) 13.sp else 15.sp
                                )
                            },
                            leadingIcon = { Icon(Icons.Default.Search, "Buscar", tint = FluxBlue) },
                            trailingIcon = {
                                IconButton(onClick = {
                                    if (searchQuery.isNotBlank()) searchQuery = "" else searchVisible = false
                                }) { Icon(Icons.Default.Close, "Cerrar buscador") }
                            },
                            shape = RoundedCornerShape(18.dp)
                        )
                        Spacer(Modifier.width(if (compact) 4.dp else 8.dp))
                        Text(
                            "${filtered.size}",
                            color = FluxTextMuted,
                            fontSize = if (compact) 14.sp else 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text(
                            selectedTitle,
                            fontSize = if (compact) 25.sp else 31.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.width(14.dp))
                        Text(
                            "${filtered.size} elementos",
                            color = FluxTextMuted,
                            fontSize = if (compact) 15.sp else 18.sp
                        )
                        Spacer(Modifier.weight(1f))
                    }

                    Spacer(Modifier.width(if (compact) 4.dp else 8.dp))
                    IconButton(
                        onClick = { scope.launch { reload(forceNetwork = true) } },
                        modifier = Modifier.size(if (compact) 42.dp else 48.dp)
                    ) {
                        Icon(Icons.Default.Refresh, "Actualizar", modifier = Modifier.size(if (compact) 27.dp else 32.dp))
                    }
                    if (!searchVisible) {
                        Spacer(Modifier.width(if (compact) 2.dp else 6.dp))
                        IconButton(
                            onClick = { searchVisible = true },
                            modifier = Modifier.size(if (compact) 42.dp else 48.dp)
                        ) {
                            Icon(Icons.Default.Search, "Buscar", modifier = Modifier.size(if (compact) 27.dp else 32.dp))
                        }
                    }
                }

                Spacer(Modifier.height(if (compact) 8.dp else 12.dp))

                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(if (compact) 12.dp else 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .width(sidebarWidth)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(if (compact) 18.dp else 24.dp))
                            .background(Color(0xEE070D18))
                            .border(1.dp, FluxLine, RoundedCornerShape(if (compact) 18.dp else 24.dp))
                            .padding(if (compact) 10.dp else 14.dp)
                    ) {
                        Text(
                            "CATEGORÍAS",
                            color = FluxTextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (compact) 11.sp else 13.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                        Spacer(Modifier.height(5.dp))
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp),
                            contentPadding = PaddingValues(bottom = 14.dp)
                        ) {
                            if (type == CatalogType.LIVE) {
                                item {
                                    CategorySidebarItem(
                                        label = "❤ FAVORITOS",
                                        count = content.count { it.id in favoriteChannelIds },
                                        selected = selectedCategory == FAVORITES_SECTION,
                                        compact = compact
                                    ) { selectedCategory = FAVORITES_SECTION }
                                }
                            } else {
                                item {
                                    CategorySidebarItem(
                                        label = "AÑADIDAS RECIENTEMENTE",
                                        count = recentlyAdded.size,
                                        selected = selectedCategory == RECENT_SECTION,
                                        compact = compact
                                    ) { selectedCategory = RECENT_SECTION }
                                }
                            }
                            item {
                                CategorySidebarItem(
                                    label = "TODO",
                                    count = content.size,
                                    selected = selectedCategory.isBlank(),
                                    compact = compact
                                ) { selectedCategory = "" }
                            }
                            items(categories, key = { it.id }) { category ->
                                val count = content.count { it.categoryId == category.id }
                                CategorySidebarItem(
                                    label = category.name,
                                    count = count,
                                    selected = selectedCategory == category.id,
                                    compact = compact
                                ) { selectedCategory = category.id }
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when {
                            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = FluxBlue)
                            }
                            error.isNotBlank() -> ErrorPanel(error) { scope.launch { reload(forceNetwork = true) } }
                            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    if (selectedCategory == FAVORITES_SECTION) "Todavía no has añadido canales favoritos."
                                    else "No hay contenido en esta categoría.",
                                    color = FluxTextMuted
                                )
                            }
                            else -> LazyVerticalGrid(
                                columns = GridCells.Adaptive(if (compact) 165.dp else 190.dp),
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp),
                                verticalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp),
                                contentPadding = PaddingValues(end = 4.dp, bottom = 24.dp)
                            ) {
                                items(filtered, key = { "${type.name}-${it.id}" }) { item ->
                                    StreamCard(
                                        item = item,
                                        type = type,
                                        isFavorite = type == CatalogType.LIVE && item.id in favoriteChannelIds,
                                        requestInitialFocus = !searchVisible && filtered.firstOrNull()?.id == item.id,
                                        onToggleFavorite = if (type == CatalogType.LIVE) {
                                            {
                                                favoriteChannelIds = ChannelFavorites.toggle(context, session, item.id)
                                            }
                                        } else null,
                                        onDoubleClick = {
                                            when (type) {
                                                CatalogType.SERIES -> onSeries(item)
                                                else -> openPlayer(
                                                    context, session, type, item.id, item.extension,
                                                    item.name, item.directSource, startFullscreen = true
                                                )
                                            }
                                        }
                                    ) {
                                        if (type == CatalogType.SERIES) {
                                            onSeries(item)
                                        } else {
                                            openPlayer(context, session, type, item.id, item.extension, item.name, item.directSource)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategorySidebarItem(
    label: String,
    count: Int,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val active = selected || focused
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(if (compact) 12.dp else 15.dp))
            .background(if (active) FluxBlue else Color.Transparent)
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else if (selected) Color(0xFF5DB6FF) else Color.Transparent,
                shape = RoundedCornerShape(if (compact) 12.dp else 15.dp)
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = if (compact) 12.dp else 15.dp, vertical = if (compact) 10.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            modifier = Modifier.weight(1f),
            color = Color.White,
            fontSize = if (compact) 13.sp else 15.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.width(8.dp))
        Text(
            count.toString(),
            color = if (active) Color.White else FluxTextMuted,
            fontSize = if (compact) 12.sp else 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(
        label,
        modifier = Modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(50))
            .background(if (selected || focused) FluxBlue else Color(0xFF17243A))
            .border(1.dp, if (focused) Color.White else FluxLine, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 17.dp, vertical = 10.dp),
        color = Color.White,
        fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StreamCard(
    item: StreamItem,
    type: CatalogType,
    isFavorite: Boolean = false,
    requestInitialFocus: Boolean = false,
    onToggleFavorite: (() -> Unit)? = null,
    onDoubleClick: () -> Unit,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(requestInitialFocus, item.id) {
        if (requestInitialFocus) {
            delay(120)
            runCatching { focusRequester.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onDoubleClick = onDoubleClick)
            .focusable()
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (item.image.isNotBlank()) {
                AsyncImage(
                    model = item.image,
                    contentDescription = item.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            } else {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(55.dp), tint = FluxTextMuted)
            }

            if (type == CatalogType.LIVE && onToggleFavorite != null) {
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(5.dp)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xD9081222))
                ) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isFavorite) "Quitar de favoritos" else "Añadir a favoritos",
                        tint = if (isFavorite) Color(0xFFFF4E78) else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Text(item.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (item.rating.isNotBlank()) {
            Text("★ ${item.rating}", color = Color(0xFFFFC862), fontSize = 12.sp)
        }
        if (focused) {
            Text(
                if (type == CatalogType.SERIES) "OK: abrir" else "Doble clic: pantalla completa",
                color = FluxBlue,
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SeriesDetailScreen(session: Session, series: StreamItem, onBack: () -> Unit) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }

    LaunchedEffect(series.id) {
        val cached = CatalogCache.loadEpisodes(context, session, series.id)
        if (!cached.isNullOrEmpty()) {
            episodes = cached
            loading = false
            return@LaunchedEffect
        }

        try {
            episodes = ApiClient.fetchSeriesEpisodes(session, series.id)
            if (episodes.isNotEmpty()) {
                CatalogCache.saveEpisodes(context, session, series.id, episodes)
            }
        } catch (exception: Exception) {
            error = exception.message ?: "No fue posible cargar los episodios."
        } finally {
            loading = false
        }
    }

    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(series.name, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(12.dp))
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error.isNotBlank() -> ErrorPanel(error, onBack)
                episodes.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Esta serie no devolvió episodios.", color = FluxTextMuted)
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(episodes, key = { it.id }) { episode ->
                        EpisodeRow(
                            episode = episode,
                            requestInitialFocus = episodes.firstOrNull()?.id == episode.id,
                            onDoubleClick = {
                                openPlayer(
                                    context, session, CatalogType.SERIES,
                                    episode.id, episode.extension, episode.title,
                                    parentSeriesId = series.id,
                                    startFullscreen = true
                                )
                            }
                        ) {
                            openPlayer(context, session, CatalogType.SERIES, episode.id, episode.extension, episode.title, parentSeriesId = series.id)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EpisodeRow(
    episode: Episode,
    requestInitialFocus: Boolean = false,
    onDoubleClick: () -> Unit,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(requestInitialFocus, episode.id) {
        if (requestInitialFocus) {
            delay(120)
            runCatching { focusRequester.requestFocus() }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onDoubleClick = onDoubleClick)
            .focusable()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 140.dp, height = 82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (episode.image.isNotBlank()) {
                AsyncImage(episode.image, episode.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text("Temporada ${episode.season} · Episodio ${episode.number}", color = FluxBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(episode.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (episode.description.isNotBlank()) {
                Text(episode.description, color = FluxTextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (focused) {
                Text("Doble clic: pantalla completa", color = FluxBlue, fontSize = 11.sp)
            }
        }
        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp))
    }
}

@Composable
private fun PlaceholderScreen(title: String, message: String, onBack: () -> Unit) {
    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(title, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier
                        .width(520.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(FluxPanel)
                        .border(1.dp, FluxLine, RoundedCornerShape(24.dp))
                        .padding(30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Settings, null, modifier = Modifier.size(65.dp), tint = FluxPurple)
                    Spacer(Modifier.height(16.dp))
                    Text("Módulo preparado", fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Text(message, color = FluxTextMuted)
                }
            }
        }
    }
}

@Composable
private fun LegacySettingsScreen(session: Session, onBack: () -> Unit, onLogout: () -> Unit) {
    BrandedBackground {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(20.dp))
            SettingsValue("Usuario", session.username)
            SettingsValue("DNS activa", session.baseUrl)
            SettingsValue("Estado", session.status)
            SettingsValue("Vencimiento", session.expiration)
            SettingsValue("Conexiones", "${session.activeConnections} de ${session.maxConnections}")
            SettingsValue("Tipo de cuenta", if (session.isTrial) "Prueba" else "Normal")
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB42345)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }
    }
}

@Composable
private fun SettingsValue(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(FluxPanel)
            .border(1.dp, FluxLine, RoundedCornerShape(15.dp))
            .padding(15.dp)
    ) {
        Text(label, color = FluxTextMuted, fontSize = 12.sp)
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ErrorPanel(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(message, color = Color(0xFFFF9AAC))
            Spacer(Modifier.height(14.dp))
            Button(onClick = onRetry) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Reintentar")
            }
        }
    }
}

@Composable
private fun BrandedBackground(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val themeBackground = when (AppPreferences.theme(context)) {
        "Morado neón" -> Color(0xFF10051E)
        "Esmeralda" -> Color(0xFF031812)
        "Rojo cinema" -> Color(0xFF1A0508)
        "Negro OLED" -> Color.Black
        else -> FluxBackground
    }
    Box(Modifier.fillMaxSize().background(themeBackground)) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.30f
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xE6050B19)),
                        radius = 1200f
                    )
                )
        )
        content()
    }
}


@Composable
private fun MiniPlayerOverlay() {
    val context = LocalContext.current
    val shouldShow = MiniPlayerState.visible
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var hasMedia by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("FluxPlay") }

    DisposableEffect(context, shouldShow) {
        if (!shouldShow) {
            controller = null
            hasMedia = false
            onDispose { }
        } else {
            val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
            val future = MediaController.Builder(context, token).buildAsync()
            future.addListener(
                {
                    runCatching { future.get() }.onSuccess { mediaController ->
                        controller = mediaController
                        hasMedia = mediaController.mediaItemCount > 0
                        isPlaying = mediaController.isPlaying
                        title = mediaController.mediaMetadata.title?.toString().orEmpty()
                            .ifBlank { "FluxPlay" }
                    }
                },
                ContextCompat.getMainExecutor(context)
            )
            onDispose {
                controller = null
                hasMedia = false
                MediaController.releaseFuture(future)
            }
        }
    }

    LaunchedEffect(controller, shouldShow) {
        while (shouldShow) {
            val active = controller
            hasMedia = active?.mediaItemCount?.let { it > 0 } == true
            isPlaying = active?.isPlaying == true
            title = active?.mediaMetadata?.title?.toString().orEmpty().ifBlank { "FluxPlay" }
            delay(250)
        }
    }

    val activeController = controller
    if (!shouldShow || !hasMedia || activeController == null) return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(end = 14.dp, bottom = 12.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        Column(
            modifier = Modifier
                .width(260.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xF20A1220))
                .border(2.dp, FluxBlue, RoundedCornerShape(18.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(146.dp)
                    .clickable {
                        MiniPlayerState.hide()
                        reopenMiniPlayer(context, activeController)
                    }
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { viewContext ->
                        PlayerView(viewContext).apply {
                            useController = false
                            player = activeController
                        }
                    },
                    update = { it.player = activeController }
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(7.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    MiniControlButton(
                        icon = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        description = if (isPlaying) "Pausar" else "Reproducir"
                    ) {
                        if (isPlaying) activeController.pause() else activeController.play()
                    }
                    MiniControlButton(Icons.Default.Fullscreen, "Ampliar") {
                        MiniPlayerState.hide()
                        reopenMiniPlayer(context, activeController)
                    }
                    MiniControlButton(Icons.Default.Close, "Cerrar") {
                        activeController.stop()
                        activeController.clearMediaItems()
                        MiniPlayerState.hide()
                        hasMedia = false
                    }
                }
            }
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun MiniControlButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(32.dp).clip(CircleShape).background(Color(0xD9000000))
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(19.dp))
    }
}

private fun reopenMiniPlayer(context: Context, controller: MediaController) {
    MiniPlayerState.hide()
    val prefs = context.getSharedPreferences("fluxplay_mini", Context.MODE_PRIVATE)
    val currentUrl = controller.currentMediaItem?.mediaId.orEmpty()
    if (currentUrl.isBlank()) return
    context.startActivity(
        Intent(context, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, prefs.getString("url", currentUrl) ?: currentUrl)
            .putExtra(PlayerActivity.EXTRA_DIRECT_SOURCE, prefs.getString("direct", "") ?: "")
            .putExtra(PlayerActivity.EXTRA_TITLE, prefs.getString("title", "FluxPlay") ?: "FluxPlay")
            .putExtra(PlayerActivity.EXTRA_STREAM_ID, prefs.getInt("id", 0))
            .putExtra(PlayerActivity.EXTRA_TYPE, prefs.getString("type", CatalogType.LIVE.name) ?: CatalogType.LIVE.name)
            .putExtra(PlayerActivity.EXTRA_PARENT_SERIES_ID, prefs.getInt("parent_series_id", 0))
    )
}

private fun openPlayer(
    context: Context,
    session: Session,
    type: CatalogType,
    itemId: Int,
    extension: String,
    title: String,
    directSource: String = "",
    parentSeriesId: Int = 0,
    startFullscreen: Boolean = false
) {
    MiniPlayerState.hide()
    val safeUser = Uri.encode(session.username)
    val safePassword = Uri.encode(session.password)
    val safeExtension = extension.ifBlank { if (type == CatalogType.LIVE) "ts" else "mp4" }
    val constructedUrl = "${session.baseUrl.trimEnd('/')}/${type.route}/$safeUser/$safePassword/$itemId.$safeExtension"
    val cleanDirect = directSource.trim().replace("\\/", "/").replace("&amp;", "&")
    val directUrl = when {
        cleanDirect.startsWith("http://") || cleanDirect.startsWith("https://") -> cleanDirect
        cleanDirect.startsWith("/") -> session.baseUrl.trimEnd('/') + cleanDirect
        cleanDirect.isNotBlank() -> session.baseUrl.trimEnd('/') + "/" + cleanDirect
        else -> ""
    }
    val url = if (type == CatalogType.LIVE && directUrl.isNotBlank() &&
        AppPreferences.streamFormat(context) in listOf("Automático", "Fuente directa")) directUrl else constructedUrl

    context.getSharedPreferences("fluxplay_mini", Context.MODE_PRIVATE).edit()
        .putString("url", constructedUrl)
        .putString("direct", directUrl)
        .putString("title", title)
        .putInt("id", itemId)
        .putString("type", type.name)
        .putInt("parent_series_id", parentSeriesId)
        .apply()

    if (AppPreferences.playerMode(context) == "Reproductor externo") {
        val external = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            when (AppPreferences.externalPlayer(context)) {
                "VLC" -> setPackage("org.videolan.vlc")
                "MX Player" -> setPackage("com.mxtech.videoplayer.ad")
                else -> Unit
            }
        }
        if (runCatching { context.startActivity(external) }.isSuccess) return
    }

    context.startActivity(
        Intent(context, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, url)
            .putExtra(PlayerActivity.EXTRA_DIRECT_SOURCE, directUrl)
            .putExtra(PlayerActivity.EXTRA_TITLE, title)
            .putExtra(PlayerActivity.EXTRA_STREAM_ID, itemId)
            .putExtra(PlayerActivity.EXTRA_TYPE, type.name)
            .putExtra(PlayerActivity.EXTRA_PARENT_SERIES_ID, parentSeriesId)
            .putExtra(PlayerActivity.EXTRA_START_FULLSCREEN, startFullscreen)
    )
}
