package com.fluxplay.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val FluxBlue = Color(0xFF198BFF)
private val FluxPurple = Color(0xFF7438FF)
private val FluxOrange = Color(0xFFFF7A28)
private val FluxBackground = Color(0xFF050B19)
private val FluxPanel = Color(0xD90B162B)
private val FluxLine = Color(0xFF243A5E)
private val FluxTextMuted = Color(0xFF9EB2CF)

private sealed interface AppScreen {
    data object Splash : AppScreen
    data object Login : AppScreen
    data object Dashboard : AppScreen
    data class Catalog(val type: CatalogType) : AppScreen
    data class SeriesDetail(val series: StreamItem) : AppScreen
    data class Placeholder(val title: String, val message: String) : AppScreen
    data object Settings : AppScreen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = FluxBlue,
                    secondary = FluxPurple,
                    background = FluxBackground,
                    surface = FluxPanel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                FluxPlayApplication()
            }
        }
    }
}

@Composable
private fun FluxPlayApplication() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf<AppScreen>(AppScreen.Splash) }
    var session by remember { mutableStateOf<Session?>(null) }
    var startupError by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        delay(2_000)
        val stored = SessionManager.load(context)
        if (stored == null) {
            screen = AppScreen.Login
            return@LaunchedEffect
        }
        try {
            val config = ApiClient.fetchConfig()
            if (config.maintenance) {
                startupError = config.maintenanceMessage.ifBlank { "Servicio temporalmente en mantenimiento." }
                screen = AppScreen.Login
                return@LaunchedEffect
            }
            val renewed = authenticateUsingConfig(config, stored.username, stored.password)
            SessionManager.save(context, renewed)
            session = renewed
            screen = AppScreen.Dashboard
        } catch (error: Exception) {
            SessionManager.clear(context)
            startupError = "Vuelve a iniciar sesión. ${error.message.orEmpty()}".trim()
            screen = AppScreen.Login
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = FluxBackground) {
        when (val destination = screen) {
            AppScreen.Splash -> SplashScreen()
            AppScreen.Login -> LoginScreen(
                initialError = startupError,
                onLogin = { newSession ->
                    session = newSession
                    SessionManager.save(context, newSession)
                    startupError = ""
                    screen = AppScreen.Dashboard
                }
            )
            AppScreen.Dashboard -> session?.let { activeSession ->
                DashboardScreen(
                    session = activeSession,
                    onOpen = { screen = it },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
            is AppScreen.Catalog -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                CatalogScreen(
                    session = activeSession,
                    type = destination.type,
                    onBack = { screen = AppScreen.Dashboard },
                    onSeries = { screen = AppScreen.SeriesDetail(it) }
                )
            }
            is AppScreen.SeriesDetail -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Catalog(CatalogType.SERIES) }
                SeriesDetailScreen(
                    session = activeSession,
                    series = destination.series,
                    onBack = { screen = AppScreen.Catalog(CatalogType.SERIES) }
                )
            }
            is AppScreen.Placeholder -> {
                BackHandler { screen = AppScreen.Dashboard }
                PlaceholderScreen(destination.title, destination.message) {
                    screen = AppScreen.Dashboard
                }
            }
            AppScreen.Settings -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                SettingsScreen(
                    session = activeSession,
                    onBack = { screen = AppScreen.Dashboard },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
        }
    }
}

private suspend fun authenticateUsingConfig(config: AppConfig, username: String, password: String): Session {
    var lastError: Exception? = null
    for (dns in listOf(config.primaryDns) + config.backupDns) {
        try {
            return ApiClient.authenticate(dns, username, password)
        } catch (error: Exception) {
            lastError = error
        }
    }
    throw lastError ?: IllegalStateException("No fue posible conectar con los servidores configurados.")
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier.fillMaxWidth(0.72f),
            contentScale = ContentScale.Fit
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginScreen(initialError: String, onLogin: (Session) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember(initialError) { mutableStateOf(initialError) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    BrandedBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // Los teléfonos en horizontal tienen bastante ancho, pero muy poca altura.
            // Se adapta por altura para que el botón Entrar nunca quede fuera de pantalla.
            val shortScreen = maxHeight < 540.dp
            val narrowScreen = maxWidth < 700.dp
            val outerPadding = if (shortScreen) 12.dp else if (narrowScreen) 20.dp else 46.dp
            val panelPadding = if (shortScreen) 16.dp else 30.dp
            val itemSpacing = if (shortScreen) 8.dp else 16.dp

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .padding(outerPadding),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!narrowScreen) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (shortScreen) 190.dp else 310.dp),
                            contentScale = ContentScale.Fit
                        )
                        if (!shortScreen) {
                            Text(
                                "Tu entretenimiento, conectado siempre.",
                                color = FluxTextMuted,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(start = 34.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(if (shortScreen) 18.dp else 36.dp))
                }

                Column(
                    modifier = Modifier
                        .then(
                            when {
                                shortScreen && !narrowScreen -> Modifier
                                    .widthIn(min = 390.dp, max = 520.dp)
                                    .fillMaxHeight()
                                narrowScreen -> Modifier.fillMaxWidth()
                                else -> Modifier.width(430.dp)
                            }
                        )
                        .clip(RoundedCornerShape(if (shortScreen) 22.dp else 28.dp))
                        .background(FluxPanel)
                        .border(
                            1.dp,
                            FluxLine,
                            RoundedCornerShape(if (shortScreen) 22.dp else 28.dp)
                        )
                        .verticalScroll(rememberScrollState())
                        .padding(panelPadding),
                    verticalArrangement = Arrangement.spacedBy(itemSpacing)
                ) {
                    if (narrowScreen && !shortScreen) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Text(
                        "Iniciar sesión",
                        fontSize = if (shortScreen) 25.sp else 30.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "Ingresa el usuario y la contraseña entregados por tu proveedor.",
                        color = FluxTextMuted,
                        fontSize = if (shortScreen) 14.sp else 16.sp,
                        maxLines = if (shortScreen) 2 else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.trim() },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Usuario") },
                        leadingIcon = { Icon(Icons.Default.Person, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Contraseña") },
                        leadingIcon = { Icon(Icons.Default.Lock, null) },
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (errorMessage.isNotBlank()) {
                        Text(
                            errorMessage,
                            color = Color(0xFFFF8EA1),
                            fontSize = if (shortScreen) 12.sp else 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x332B0010))
                                .padding(if (shortScreen) 8.dp else 12.dp)
                        )
                    }
                    Button(
                        onClick = {
                            if (username.isBlank() || password.isBlank()) {
                                errorMessage = "Escribe el usuario y la contraseña."
                                return@Button
                            }
                            scope.launch {
                                loading = true
                                errorMessage = ""
                                try {
                                    val config = ApiClient.fetchConfig()
                                    if (config.maintenance) {
                                        throw IllegalStateException(
                                            config.maintenanceMessage.ifBlank { "Servicio en mantenimiento." }
                                        )
                                    }
                                    onLogin(authenticateUsingConfig(config, username, password))
                                } catch (error: Exception) {
                                    errorMessage = error.message ?: "No fue posible iniciar sesión."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (shortScreen) 50.dp else 58.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FluxBlue),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(25.dp),
                                strokeWidth = 3.dp
                            )
                        } else {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Entrar a FluxPlay",
                                fontSize = if (shortScreen) 15.sp else 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (!shortScreen) {
                        Text(
                            "La DNS se obtiene automáticamente desde FluxPlay Control.",
                            color = FluxTextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    session: Session,
    onOpen: (AppScreen) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var liveItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var movieItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var seriesItems by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var loadingContent by remember { mutableStateOf(true) }
    var countError by remember { mutableStateOf("") }

    LaunchedEffect(session) {
        loadingContent = true
        countError = ""
        try {
            coroutineScope {
                val live = async { ApiClient.fetchItems(session, CatalogType.LIVE) }
                val movies = async { ApiClient.fetchItems(session, CatalogType.MOVIES) }
                val series = async { ApiClient.fetchItems(session, CatalogType.SERIES) }
                liveItems = live.await()
                movieItems = movies.await()
                seriesItems = series.await()
            }
        } catch (error: Exception) {
            countError = error.message.orEmpty()
        } finally {
            loadingContent = false
        }
    }

    val featuredMovie = remember(movieItems) {
        movieItems.firstOrNull { it.image.isNotBlank() } ?: movieItems.firstOrNull()
    }

    BrandedBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxHeight < 560.dp || maxWidth < 1_080.dp
            val outerPadding = if (compact) 10.dp else 18.dp
            val gap = if (compact) 9.dp else 14.dp

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(outerPadding)
            ) {
                Sidebar(
                    compact = compact,
                    selected = "Inicio",
                    onHome = {},
                    onLive = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) },
                    onMovies = { onOpen(AppScreen.Catalog(CatalogType.MOVIES)) },
                    onSeries = { onOpen(AppScreen.Catalog(CatalogType.SERIES)) },
                    onGuide = { onOpen(AppScreen.Placeholder("TV Guide", "La guía completa se conectará al EPG del proveedor.")) },
                    onCatchUp = { onOpen(AppScreen.Placeholder("Catch Up", "Aquí aparecerán los canales que tengan programación grabada.")) },
                    onFavorites = { onOpen(AppScreen.Placeholder("Favoritos", "La biblioteca local de favoritos estará disponible en la siguiente actualización.")) },
                    onSettings = { onOpen(AppScreen.Settings) }
                )

                Spacer(Modifier.width(gap))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    HeaderBar(compact)
                    Spacer(Modifier.height(gap))

                    if (countError.isNotBlank()) {
                        Text(
                            "No se pudieron actualizar algunos datos: $countError",
                            color = Color(0xFFFFB0BC),
                            fontSize = if (compact) 10.sp else 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(5.dp))
                    }

                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(2.15f)
                                .fillMaxHeight()
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1.08f)
                                    .fillMaxWidth()
                            ) {
                                DashboardHeroCard(
                                    compact = compact,
                                    title = "LIVE TV",
                                    subtitle = if (loadingContent) "Cargando canales…" else "${liveItems.size} canales disponibles",
                                    imageUrl = liveItems.firstOrNull { it.image.isNotBlank() }?.image.orEmpty(),
                                    icon = Icons.Default.LiveTv,
                                    accent = FluxBlue,
                                    modifier = Modifier
                                        .weight(1.38f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "MOVIES",
                                    subtitle = if (loadingContent) "Cargando películas…" else "${movieItems.size} películas a tu alcance",
                                    imageUrl = featuredMovie?.image.orEmpty(),
                                    icon = Icons.Default.Movie,
                                    colors = listOf(Color(0xCC151B2B), Color(0xE60A0E18)),
                                    modifier = Modifier
                                        .weight(0.82f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.MOVIES)) }
                                )
                            }

                            Spacer(Modifier.height(gap))

                            Row(
                                modifier = Modifier
                                    .weight(0.92f)
                                    .fillMaxWidth()
                            ) {
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "SERIES",
                                    subtitle = if (loadingContent) "Cargando series…" else "${seriesItems.size} series disponibles",
                                    imageUrl = seriesItems.firstOrNull { it.image.isNotBlank() }?.image.orEmpty(),
                                    icon = Icons.Default.VideoLibrary,
                                    colors = listOf(Color(0xCC311C2D), Color(0xED10101B)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Catalog(CatalogType.SERIES)) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "TV GUIDE",
                                    subtitle = "Consulta la programación de tus canales",
                                    imageUrl = "",
                                    icon = Icons.Default.CalendarMonth,
                                    colors = listOf(Color(0xD530267B), Color(0xEB111329)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Placeholder("TV Guide", "La guía completa se conectará al EPG del proveedor.")) }
                                )
                                Spacer(Modifier.width(gap))
                                DashboardSmallCard(
                                    compact = compact,
                                    title = "CATCH UP",
                                    subtitle = "Mira nuevamente lo que te perdiste",
                                    imageUrl = "",
                                    icon = Icons.Default.History,
                                    colors = listOf(Color(0xD2075963), Color(0xEB081C26)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    onClick = { onOpen(AppScreen.Placeholder("Catch Up", "Aquí aparecerán los canales que tengan programación grabada.")) }
                                )
                            }
                        }

                        Spacer(Modifier.width(gap))

                        FeaturedDashboardCard(
                            compact = compact,
                            item = featuredMovie,
                            modifier = Modifier
                                .weight(0.92f)
                                .fillMaxHeight(),
                            onClick = {
                                val item = featuredMovie
                                if (item != null) {
                                    openPlayer(context, session, CatalogType.MOVIES, item.id, item.extension, item.name)
                                } else {
                                    onOpen(AppScreen.Catalog(CatalogType.MOVIES))
                                }
                            }
                        )
                    }

                    Spacer(Modifier.height(gap))
                    StatusBar(session = session, compact = compact, onLogout = onLogout)
                }
            }
        }
    }
}

@Composable
private fun HeaderBar(compact: Boolean) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }
    val time = remember(now) { SimpleDateFormat("hh:mm a", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(now) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 50.dp else 66.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Tu entretenimiento, en un solo lugar",
            color = FluxTextMuted,
            fontSize = if (compact) 11.sp else 14.sp,
            maxLines = 1
        )
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                time,
                fontSize = if (compact) 19.sp else 25.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
            Text(
                date,
                color = FluxTextMuted,
                fontSize = if (compact) 11.sp else 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Sidebar(
    compact: Boolean,
    selected: String,
    onHome: () -> Unit,
    onLive: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onGuide: () -> Unit,
    onCatchUp: () -> Unit,
    onFavorites: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(if (compact) 145.dp else 184.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(if (compact) 20.dp else 26.dp))
            .background(Color(0xDD030B18))
            .border(1.dp, Color(0x663D6DA8), RoundedCornerShape(if (compact) 20.dp else 26.dp))
            .padding(horizontal = if (compact) 8.dp else 13.dp, vertical = if (compact) 8.dp else 13.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 6.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 48.dp else 68.dp),
            contentScale = ContentScale.Fit
        )
        NavButton("Inicio", Icons.Default.Home, selected == "Inicio", compact, onHome)
        NavButton("Live TV", Icons.Default.LiveTv, selected == "Live TV", compact, onLive)
        NavButton("Películas", Icons.Default.Movie, selected == "Películas", compact, onMovies)
        NavButton("Series", Icons.Default.VideoLibrary, selected == "Series", compact, onSeries)
        NavButton("Guía TV", Icons.Default.CalendarMonth, selected == "Guía TV", compact, onGuide)
        NavButton("Catch Up", Icons.Default.History, selected == "Catch Up", compact, onCatchUp)
        NavButton("Favoritos", Icons.Default.FavoriteBorder, selected == "Favoritos", compact, onFavorites)
        Spacer(Modifier.weight(1f))
        NavButton("Ajustes", Icons.Default.Settings, selected == "Ajustes", compact, onSettings)
    }
}

@Composable
private fun NavButton(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val background by animateColorAsState(
        if (selected || focused) Color(0xFF0E4D98) else Color.Transparent,
        label = "nav-background"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(if (compact) 11.dp else 15.dp))
            .background(background)
            .then(
                if (focused) Modifier.border(
                    2.dp,
                    Color(0xFF59B4FF),
                    RoundedCornerShape(if (compact) 11.dp else 15.dp)
                ) else Modifier
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(
                horizontal = if (compact) 9.dp else 13.dp,
                vertical = if (compact) 6.dp else 10.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            null,
            tint = if (selected || focused) Color.White else FluxTextMuted,
            modifier = Modifier.size(if (compact) 19.dp else 23.dp)
        )
        Spacer(Modifier.width(if (compact) 8.dp else 11.dp))
        Text(
            label,
            fontSize = if (compact) 11.sp else 14.sp,
            fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
private fun DashboardHeroCard(
    compact: Boolean,
    title: String,
    subtitle: String,
    imageUrl: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 18.dp else 25.dp)
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color(0xFF0D2B57))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else Color(0x995D8BC4), shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.24f
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xF00A4EA4), Color(0xD70B1732), Color(0xF0050C18))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 14.dp else 21.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFFF385C)))
                Spacer(Modifier.width(7.dp))
                Text("En vivo ahora", fontSize = if (compact) 10.sp else 12.sp)
                Spacer(Modifier.weight(1f))
                Icon(icon, null, tint = accent, modifier = Modifier.size(if (compact) 27.dp else 35.dp))
            }
            Column {
                Text(
                    title,
                    fontSize = if (compact) 27.sp else 38.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    subtitle,
                    color = Color(0xFFD8E7FB),
                    fontSize = if (compact) 11.sp else 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
                Text(
                    "Explorar canales   ›",
                    color = Color.White,
                    fontSize = if (compact) 11.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (focused) FluxBlue else Color(0xA61765C1))
                        .padding(horizontal = if (compact) 11.dp else 15.dp, vertical = if (compact) 6.dp else 9.dp)
                )
            }
        }
    }
}

@Composable
private fun DashboardSmallCard(
    compact: Boolean,
    title: String,
    subtitle: String,
    imageUrl: String,
    icon: ImageVector,
    colors: List<Color>,
    modifier: Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 17.dp else 23.dp)
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(colors.last())
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else FluxLine, shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.46f
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors)))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 12.dp else 18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, modifier = Modifier.size(if (compact) 24.dp else 31.dp), tint = Color.White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.PlayArrow, null, tint = if (focused) FluxOrange else Color.White)
            }
            Column {
                Text(
                    title,
                    fontSize = if (compact) 19.sp else 27.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    subtitle,
                    color = Color(0xFFD3DBE9),
                    fontSize = if (compact) 10.sp else 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(if (compact) 5.dp else 8.dp))
                Text(
                    "Explorar  ›",
                    fontSize = if (compact) 10.sp else 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (focused) Color.White else Color(0xFFC2D7F4)
                )
            }
        }
    }
}

@Composable
private fun FeaturedDashboardCard(
    compact: Boolean,
    item: StreamItem?,
    modifier: Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compact) 18.dp else 25.dp)
    Box(
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color(0xFF101827))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, shape)
            .clickable(onClick = onClick)
            .focusable()
    ) {
        if (!item?.image.isNullOrBlank()) {
            AsyncImage(
                model = item?.image,
                contentDescription = item?.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Image(
                painter = painterResource(R.drawable.flux_background),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x22000000), Color(0x55000000), Color(0xF2050A14))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 14.dp else 20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "★ DESTACADO",
                    fontSize = if (compact) 9.sp else 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x99061120))
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "NUEVO",
                    fontSize = if (compact) 9.sp else 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE83259))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
            Column {
                Text("FluxPlay recomendado", color = Color(0xFFC8D4E5), fontSize = if (compact) 10.sp else 12.sp)
                Text(
                    item?.name ?: "Explora todo el catálogo",
                    fontSize = if (compact) 20.sp else 28.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (!item?.rating.isNullOrBlank()) {
                    Text("★ ${item?.rating}", color = Color(0xFFFFD166), fontSize = if (compact) 10.sp else 12.sp)
                }
                Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
                Row {
                    Text(
                        "▶  Ver ahora",
                        fontSize = if (compact) 10.sp else 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (focused) FluxBlue else Color(0xCC125DB8))
                            .padding(horizontal = if (compact) 11.dp else 15.dp, vertical = if (compact) 7.dp else 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBar(session: Session, compact: Boolean, onLogout: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 43.dp else 56.dp)
            .clip(RoundedCornerShape(if (compact) 14.dp else 18.dp))
            .background(Color(0xE5091529))
            .border(1.dp, FluxLine, RoundedCornerShape(if (compact) 14.dp else 18.dp))
            .padding(horizontal = if (compact) 13.dp else 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Lock, null, tint = FluxBlue, modifier = Modifier.size(if (compact) 16.dp else 20.dp))
        Spacer(Modifier.width(7.dp))
        Text("EXPIRACIÓN:", color = Color(0xFF55B9FF), fontSize = if (compact) 10.sp else 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(7.dp))
        Text(session.expiration, fontSize = if (compact) 11.sp else 14.sp, maxLines = 1)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF31E58B)))
        Spacer(Modifier.width(7.dp))
        Text("Conectado:", color = FluxTextMuted, fontSize = if (compact) 10.sp else 13.sp)
        Spacer(Modifier.width(5.dp))
        Text(session.username, fontSize = if (compact) 11.sp else 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.width(if (compact) 5.dp else 10.dp))
        IconButton(onClick = onLogout, modifier = Modifier.size(if (compact) 31.dp else 40.dp)) {
            Icon(Icons.Default.Logout, "Cerrar sesión", modifier = Modifier.size(if (compact) 17.dp else 21.dp))
        }
    }
}

@Composable
private fun CatalogScreen(
    session: Session,
    type: CatalogType,
    onBack: () -> Unit,
    onSeries: (StreamItem) -> Unit
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var content by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var selectedCategory by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    suspend fun reload() {
        loading = true
        error = ""
        try {
            coroutineScope {
                val categoryJob = async { ApiClient.fetchCategories(session, type) }
                val contentJob = async { ApiClient.fetchItems(session, type) }
                categories = categoryJob.await()
                content = contentJob.await()
            }
        } catch (exception: Exception) {
            error = exception.message ?: "No fue posible cargar el contenido."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(type) { reload() }
    val filtered = remember(content, selectedCategory) {
        if (selectedCategory.isBlank()) content else content.filter { it.categoryId == selectedCategory }
    }
    val selectedTitle = remember(categories, selectedCategory, type) {
        categories.firstOrNull { it.id == selectedCategory }?.name ?: type.title
    }

    BrandedBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxHeight < 520.dp
            val sidebarWidth = if (maxWidth < 1050.dp) 245.dp else 305.dp
            val pagePadding = if (compact) 12.dp else 18.dp

            Column(Modifier.fillMaxSize().padding(pagePadding)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.size(if (compact) 42.dp else 48.dp)) {
                        Icon(Icons.Default.ArrowBack, "Regresar", modifier = Modifier.size(if (compact) 28.dp else 34.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(selectedTitle, fontSize = if (compact) 25.sp else 31.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.width(14.dp))
                    Text("${filtered.size} elementos", color = FluxTextMuted, fontSize = if (compact) 15.sp else 18.sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { reload() } }, modifier = Modifier.size(if (compact) 42.dp else 48.dp)) {
                        Icon(Icons.Default.Refresh, "Actualizar", modifier = Modifier.size(if (compact) 27.dp else 32.dp))
                    }
                }

                Spacer(Modifier.height(if (compact) 8.dp else 12.dp))

                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(if (compact) 12.dp else 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .width(sidebarWidth)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(if (compact) 18.dp else 24.dp))
                            .background(Color(0xEE070D18))
                            .border(1.dp, FluxLine, RoundedCornerShape(if (compact) 18.dp else 24.dp))
                            .padding(if (compact) 10.dp else 14.dp)
                    ) {
                        Text(
                            "CATEGORÍAS",
                            color = FluxTextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (compact) 11.sp else 13.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                        Spacer(Modifier.height(5.dp))
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 8.dp),
                            contentPadding = PaddingValues(bottom = 14.dp)
                        ) {
                            item {
                                CategorySidebarItem(
                                    label = "TODO",
                                    count = content.size,
                                    selected = selectedCategory.isBlank(),
                                    compact = compact
                                ) { selectedCategory = "" }
                            }
                            items(categories, key = { it.id }) { category ->
                                val count = content.count { it.categoryId == category.id }
                                CategorySidebarItem(
                                    label = category.name,
                                    count = count,
                                    selected = selectedCategory == category.id,
                                    compact = compact
                                ) { selectedCategory = category.id }
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when {
                            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = FluxBlue)
                            }
                            error.isNotBlank() -> ErrorPanel(error) { scope.launch { reload() } }
                            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No hay contenido en esta categoría.", color = FluxTextMuted)
                            }
                            else -> LazyVerticalGrid(
                                columns = GridCells.Adaptive(if (compact) 165.dp else 190.dp),
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp),
                                verticalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 14.dp),
                                contentPadding = PaddingValues(end = 4.dp, bottom = 24.dp)
                            ) {
                                items(filtered, key = { "${type.name}-${it.id}" }) { item ->
                                    StreamCard(item) {
                                        if (type == CatalogType.SERIES) {
                                            onSeries(item)
                                        } else {
                                            openPlayer(context, session, type, item.id, item.extension, item.name)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategorySidebarItem(
    label: String,
    count: Int,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val active = selected || focused
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(if (compact) 12.dp else 15.dp))
            .background(if (active) FluxBlue else Color.Transparent)
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else if (selected) Color(0xFF5DB6FF) else Color.Transparent,
                shape = RoundedCornerShape(if (compact) 12.dp else 15.dp)
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = if (compact) 12.dp else 15.dp, vertical = if (compact) 10.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            modifier = Modifier.weight(1f),
            color = Color.White,
            fontSize = if (compact) 13.sp else 15.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.width(8.dp))
        Text(
            count.toString(),
            color = if (active) Color.White else FluxTextMuted,
            fontSize = if (compact) 12.sp else 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(
        label,
        modifier = Modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(50))
            .background(if (selected || focused) FluxBlue else Color(0xFF17243A))
            .border(1.dp, if (focused) Color.White else FluxLine, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 17.dp, vertical = 10.dp),
        color = Color.White,
        fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1
    )
}

@Composable
private fun StreamCard(item: StreamItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (item.image.isNotBlank()) {
                AsyncImage(
                    model = item.image,
                    contentDescription = item.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            } else {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(55.dp), tint = FluxTextMuted)
            }
        }
        Spacer(Modifier.height(9.dp))
        Text(item.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (item.rating.isNotBlank()) {
            Text("★ ${item.rating}", color = Color(0xFFFFC862), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SeriesDetailScreen(session: Session, series: StreamItem, onBack: () -> Unit) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }

    LaunchedEffect(series.id) {
        try {
            episodes = ApiClient.fetchSeriesEpisodes(session, series.id)
        } catch (exception: Exception) {
            error = exception.message ?: "No fue posible cargar los episodios."
        } finally {
            loading = false
        }
    }

    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(series.name, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(12.dp))
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error.isNotBlank() -> ErrorPanel(error, onBack)
                episodes.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Esta serie no devolvió episodios.", color = FluxTextMuted)
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(episodes, key = { it.id }) { episode ->
                        EpisodeRow(episode) {
                            openPlayer(context, session, CatalogType.SERIES, episode.id, episode.extension, episode.title)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(episode: Episode, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 140.dp, height = 82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (episode.image.isNotBlank()) {
                AsyncImage(episode.image, episode.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text("Temporada ${episode.season} · Episodio ${episode.number}", color = FluxBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(episode.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (episode.description.isNotBlank()) {
                Text(episode.description, color = FluxTextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp))
    }
}

@Composable
private fun PlaceholderScreen(title: String, message: String, onBack: () -> Unit) {
    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(title, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier
                        .width(520.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(FluxPanel)
                        .border(1.dp, FluxLine, RoundedCornerShape(24.dp))
                        .padding(30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Settings, null, modifier = Modifier.size(65.dp), tint = FluxPurple)
                    Spacer(Modifier.height(16.dp))
                    Text("Módulo preparado", fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Text(message, color = FluxTextMuted)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(session: Session, onBack: () -> Unit, onLogout: () -> Unit) {
    BrandedBackground {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(20.dp))
            SettingsValue("Usuario", session.username)
            SettingsValue("DNS activa", session.baseUrl)
            SettingsValue("Estado", session.status)
            SettingsValue("Vencimiento", session.expiration)
            SettingsValue("Conexiones", "${session.activeConnections} de ${session.maxConnections}")
            SettingsValue("Tipo de cuenta", if (session.isTrial) "Prueba" else "Normal")
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB42345)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }
    }
}

@Composable
private fun SettingsValue(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(FluxPanel)
            .border(1.dp, FluxLine, RoundedCornerShape(15.dp))
            .padding(15.dp)
    ) {
        Text(label, color = FluxTextMuted, fontSize = 12.sp)
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ErrorPanel(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(message, color = Color(0xFFFF9AAC))
            Spacer(Modifier.height(14.dp))
            Button(onClick = onRetry) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Reintentar")
            }
        }
    }
}

@Composable
private fun BrandedBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(FluxBackground)) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.30f
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xE6050B19)),
                        radius = 1200f
                    )
                )
        )
        content()
    }
}

private fun openPlayer(
    context: Context,
    session: Session,
    type: CatalogType,
    itemId: Int,
    extension: String,
    title: String
) {
    val safeUser = Uri.encode(session.username)
    val safePassword = Uri.encode(session.password)
    val safeExtension = extension.ifBlank { if (type == CatalogType.LIVE) "ts" else "mp4" }
    val url = "${session.baseUrl.trimEnd('/')}/${type.route}/$safeUser/$safePassword/$itemId.$safeExtension"
    context.startActivity(
        Intent(context, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, url)
            .putExtra(PlayerActivity.EXTRA_TITLE, title)
            .putExtra(PlayerActivity.EXTRA_STREAM_ID, itemId)
            .putExtra(PlayerActivity.EXTRA_TYPE, type.name)
    )
}
