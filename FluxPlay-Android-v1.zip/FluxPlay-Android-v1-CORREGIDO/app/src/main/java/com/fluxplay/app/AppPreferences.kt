package com.fluxplay.app

import android.content.Context

object AppPreferences {
    private const val FILE = "fluxplay_settings"

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun theme(context: Context): String = prefs(context).getString("theme", "Azul noche") ?: "Azul noche"
    fun setTheme(context: Context, value: String) = prefs(context).edit().putString("theme", value).apply()

    fun timeFormat(context: Context): String = prefs(context).getString("time_format", "12 horas") ?: "12 horas"
    fun setTimeFormat(context: Context, value: String) = prefs(context).edit().putString("time_format", value).apply()

    fun streamFormat(context: Context): String = prefs(context).getString("stream_format", "Automático") ?: "Automático"
    fun setStreamFormat(context: Context, value: String) = prefs(context).edit().putString("stream_format", value).apply()

    fun autoplay(context: Context): Boolean = prefs(context).getBoolean("autoplay", true)
    fun setAutoplay(context: Context, value: Boolean) = prefs(context).edit().putBoolean("autoplay", value).apply()

    fun autoPip(context: Context): Boolean = prefs(context).getBoolean("auto_pip", true)
    fun setAutoPip(context: Context, value: Boolean) = prefs(context).edit().putBoolean("auto_pip", value).apply()

    fun epgEnabled(context: Context): Boolean = prefs(context).getBoolean("epg_enabled", true)
    fun setEpgEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean("epg_enabled", value).apply()

    fun parentalEnabled(context: Context): Boolean = prefs(context).getBoolean("parental_enabled", false)
    fun setParentalEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean("parental_enabled", value).apply()
    fun parentalPin(context: Context): String = prefs(context).getString("parental_pin", "0000") ?: "0000"
    fun setParentalPin(context: Context, value: String) = prefs(context).edit().putString("parental_pin", value).apply()

    fun playerMode(context: Context): String = prefs(context).getString("player_mode", "Interno FluxPlay") ?: "Interno FluxPlay"
    fun setPlayerMode(context: Context, value: String) = prefs(context).edit().putString("player_mode", value).apply()

    fun externalPlayer(context: Context): String = prefs(context).getString("external_player", "Preguntar siempre") ?: "Preguntar siempre"
    fun setExternalPlayer(context: Context, value: String) = prefs(context).edit().putString("external_player", value).apply()

    fun aspectMode(context: Context): String = prefs(context).getString("aspect_mode", "Ajustar") ?: "Ajustar"
    fun setAspectMode(context: Context, value: String) = prefs(context).edit().putString("aspect_mode", value).apply()

    fun bufferMode(context: Context): String = prefs(context).getString("buffer_mode", "Normal") ?: "Normal"
    fun setBufferMode(context: Context, value: String) = prefs(context).edit().putString("buffer_mode", value).apply()

    fun bufferSeconds(context: Context): Int = prefs(context).getInt("buffer_seconds", 40).coerceIn(30, 100)
    fun setBufferSeconds(context: Context, value: Int) = prefs(context).edit().putInt("buffer_seconds", value.coerceIn(30, 100)).apply()

    fun multiScreen(context: Context): Boolean = prefs(context).getBoolean("multi_screen", true)
    fun setMultiScreen(context: Context, value: Boolean) = prefs(context).edit().putBoolean("multi_screen", value).apply()

    fun deviceMode(context: Context): String = prefs(context).getString("device_mode", "Automático") ?: "Automático"
    fun setDeviceMode(context: Context, value: String) = prefs(context).edit().putString("device_mode", value).apply()
}
