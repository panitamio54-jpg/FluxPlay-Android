package com.fluxplay.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Caché de catálogo en memoria y disco.
 *
 * Evita pedir miles de canales/películas/series cada vez que el usuario
 * regresa de un reproductor o cambia de pantalla.
 */
object CatalogCache {
    private val itemMemory = ConcurrentHashMap<String, List<StreamItem>>()
    private val categoryMemory = ConcurrentHashMap<String, List<Category>>()

    private fun baseKey(session: Session, type: CatalogType): String =
        "${session.baseUrl}|${session.username}|${type.name}".hashCode().toString()

    private fun itemFile(context: Context, session: Session, type: CatalogType) =
        File(context.cacheDir, "flux_items_${baseKey(session, type)}.json")

    private fun categoryFile(context: Context, session: Session, type: CatalogType) =
        File(context.cacheDir, "flux_categories_${baseKey(session, type)}.json")

    suspend fun loadItems(
        context: Context,
        session: Session,
        type: CatalogType
    ): List<StreamItem>? = withContext(Dispatchers.IO) {
        val key = baseKey(session, type)
        itemMemory[key]?.let { return@withContext it }
        val file = itemFile(context, session, type)
        if (!file.exists()) return@withContext null
        runCatching {
            val array = JSONArray(file.readText())
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        StreamItem(
                            id = item.optInt("id"),
                            name = item.optString("name"),
                            image = item.optString("image"),
                            categoryId = item.optString("categoryId"),
                            extension = item.optString("extension"),
                            description = item.optString("description"),
                            rating = item.optString("rating"),
                            hasArchive = item.optBoolean("hasArchive", false),
                            directSource = item.optString("directSource"),
                            epgChannelId = item.optString("epgChannelId")
                        )
                    )
                }
            }.also { itemMemory[key] = it }
        }.getOrNull()
    }

    suspend fun loadCategories(
        context: Context,
        session: Session,
        type: CatalogType
    ): List<Category>? = withContext(Dispatchers.IO) {
        val key = baseKey(session, type)
        categoryMemory[key]?.let { return@withContext it }
        val file = categoryFile(context, session, type)
        if (!file.exists()) return@withContext null
        runCatching {
            val array = JSONArray(file.readText())
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(Category(item.optString("id"), item.optString("name")))
                }
            }.also { categoryMemory[key] = it }
        }.getOrNull()
    }

    suspend fun saveItems(
        context: Context,
        session: Session,
        type: CatalogType,
        items: List<StreamItem>
    ) = withContext(Dispatchers.IO) {
        val key = baseKey(session, type)
        itemMemory[key] = items
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject()
                    .put("id", item.id)
                    .put("name", item.name)
                    .put("image", item.image)
                    .put("categoryId", item.categoryId)
                    .put("extension", item.extension)
                    .put("description", item.description)
                    .put("rating", item.rating)
                    .put("hasArchive", item.hasArchive)
                    .put("directSource", item.directSource)
                    .put("epgChannelId", item.epgChannelId)
            )
        }
        runCatching { itemFile(context, session, type).writeText(array.toString()) }
    }

    suspend fun saveCategories(
        context: Context,
        session: Session,
        type: CatalogType,
        categories: List<Category>
    ) = withContext(Dispatchers.IO) {
        val key = baseKey(session, type)
        categoryMemory[key] = categories
        val array = JSONArray()
        categories.forEach { category ->
            array.put(
                JSONObject()
                    .put("id", category.id)
                    .put("name", category.name)
            )
        }
        runCatching { categoryFile(context, session, type).writeText(array.toString()) }
    }

    fun clearMemory() {
        itemMemory.clear()
        categoryMemory.clear()
    }
}
