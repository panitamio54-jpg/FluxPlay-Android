package com.fluxplay.app

import androidx.media3.exoplayer.ExoPlayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.rotate
import androidx.compose.material3.Slider
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.foundation.layout.offset
import android.widget.Toast
import android.provider.Settings
import android.media.AudioManager
import android.content.Intent
import android.content.Context
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PlayerBlue = Color(0xFF198BFF)
private val PlayerPurple = Color(0xFF5A38B7)
private val PlayerBackground = Color(0xFF030A18)
private val PlayerPanel = Color(0xE70A1730)
private val PlayerLine = Color(0xFF29446D)
private val PlayerMuted = Color(0xFFA9B8CE)

class PlayerActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)
    private var liveChannels by mutableStateOf<List<StreamItem>>(emptyList())
    private var categoryNames by mutableStateOf<Map<String, String>>(emptyMap())
    private var selectedStreamId by mutableStateOf(0)
    private var selectedTitle by mutableStateOf("")
    private var listLoading by mutableStateOf(false)
    private var inPictureInPicture by mutableStateOf(false)
    private var fullScreenVideo by mutableStateOf(false)
    private var currentProgram by mutableStateOf<EpgProgram?>(null)
    private var nextProgram by mutableStateOf<EpgProgram?>(null)
    private var epgLoading by mutableStateOf(false)
    private var mediaType = CatalogType.LIVE
    private var session: Session? = null
    private var selectedDirectSource = ""
    private var playbackCandidates: List<String> = emptyList()
    private var playbackCandidateIndex = 0
    private var playbackTitle = ""
    private var switchingSource = false
    private var playbackErrorMessage by mutableStateOf("")
    private var returningInsideApp = false
    private var movieItems by mutableStateOf<List<StreamItem>>(emptyList())
    private var seriesEpisodes by mutableStateOf<List<Episode>>(emptyList())
    private var parentSeriesId = 0
    private var firstFrameRendered = false
    private var firstFrameFallbackJob: Job? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val isPrevious = event.keyCode == KeyEvent.KEYCODE_DPAD_UP ||
                event.keyCode == KeyEvent.KEYCODE_PAGE_UP ||
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_UP
            val isNext = event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
                event.keyCode == KeyEvent.KEYCODE_PAGE_DOWN ||
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_DOWN

            if (isPrevious || isNext) {
                if (mediaType == CatalogType.LIVE && fullScreenVideo) {
                    val selected = liveChannels.firstOrNull { it.id == selectedStreamId }
                    if (selected != null) {
                        val channels = channelsForSelectedCategory(selected)
                        if (channels.isNotEmpty()) {
                            val currentIndex = channels.indexOfFirst { it.id == selectedStreamId }
                                .let { if (it < 0) 0 else it }
                            val targetIndex = if (isPrevious) {
                                (currentIndex - 1 + channels.size) % channels.size
                            } else {
                                (currentIndex + 1) % channels.size
                            }
                            playLiveChannel(channels[targetIndex])
                            return true
                        }
                    }
                } else if (mediaType == CatalogType.MOVIES || mediaType == CatalogType.SERIES) {
                    if (playAdjacentContent(previous = isPrevious)) return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        selectedTitle = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        selectedStreamId = intent.getIntExtra(EXTRA_STREAM_ID, 0)
        selectedDirectSource = intent.getStringExtra(EXTRA_DIRECT_SOURCE).orEmpty()
        parentSeriesId = intent.getIntExtra(EXTRA_PARENT_SERIES_ID, 0)
        mediaType = runCatching {
            CatalogType.valueOf(intent.getStringExtra(EXTRA_TYPE).orEmpty())
        }.getOrDefault(CatalogType.LIVE)
        fullScreenVideo = intent.getBooleanExtra(EXTRA_START_FULLSCREEN, false)
        session = SessionManager.load(this)

        if (url.isBlank()) {
            finish()
            return
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color.Black,
                    surface = PlayerPanel,
                    primary = PlayerBlue
                )
            ) {
                val activeController = controller
                val selected = liveChannels.firstOrNull { it.id == selectedStreamId }
                    ?: StreamItem(
                        id = selectedStreamId,
                        name = selectedTitle.ifBlank { "Canal en vivo" },
                        image = "",
                        categoryId = "",
                        extension = "ts",
                        description = "",
                        rating = "",
                        directSource = selectedDirectSource
                    )

                BackHandler(enabled = !fullScreenVideo && !inPictureInPicture) {
                    returnToCatalogWithMiniPlayer()
                }

                when {
                    activeController == null -> LoadingPlayer()
                    inPictureInPicture -> PictureInPictureVideo(activeController)
                    fullScreenVideo && mediaType == CatalogType.LIVE -> FullScreenLivePlayer(
                        player = activeController,
                        selected = selected,
                        channels = channelsForSelectedCategory(selected),
                        currentProgram = currentProgram,
                        nextProgram = nextProgram,
                        epgLoading = epgLoading,
                        buildStreamUrl = { buildLiveUrl(it) },
                        onSelectChannel = { playLiveChannel(it) },
                        onExit = {
                            fullScreenVideo = false
                            hideSystemUi()
                        }
                    )
                    fullScreenVideo -> FullScreenVodPlayer(
                        player = activeController,
                        title = selectedTitle,
                        mediaType = mediaType,
                        canNavigate = navigationSize() > 1,
                        onPrevious = { playAdjacentContent(previous = true) },
                        onNext = { playAdjacentContent(previous = false) },
                        onExit = {
                            fullScreenVideo = false
                            hideSystemUi()
                        }
                    )
                    mediaType != CatalogType.LIVE -> VodPlayerDashboard(
                        player = activeController,
                        title = selectedTitle,
                        mediaType = mediaType,
                        canNavigate = navigationSize() > 1,
                        onPrevious = { playAdjacentContent(previous = true) },
                        onNext = { playAdjacentContent(previous = false) },
                        onBack = { returnToCatalogWithMiniPlayer() },
                        onFullscreen = {
                            fullScreenVideo = true
                            hideSystemUi()
                        }
                    )
                    else -> {
                        LivePlayerDashboard(
                            player = activeController,
                            selected = selected,
                            channels = channelsForSelectedCategory(selected),
                            categoryTitle = categoryNames[selected.categoryId] ?: "TV EN VIVO",
                            loadingChannels = listLoading,
                            currentProgram = currentProgram,
                            nextProgram = nextProgram,
                            epgLoading = epgLoading,
                            playbackError = playbackErrorMessage,
                            onBack = { returnToCatalogWithMiniPlayer() },
                            onFullscreen = {
                                fullScreenVideo = true
                                hideSystemUi()
                            },
                            onSelectChannel = { playLiveChannel(it) }
                        )
                    }
                }
            }
        }

        connectController(url, selectedTitle)
        when (mediaType) {
            CatalogType.LIVE -> {
                loadLiveCatalog()
                if (selectedStreamId > 0) loadEpg(selectedStreamId)
            }
            CatalogType.MOVIES -> loadMovieNavigation()
            CatalogType.SERIES -> loadSeriesNavigation()
        }
    }

    private fun connectController(url: String, title: String) {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener(
                {
                    try {
                        val mediaController = future.get()
                        controller = mediaController
                        mediaController.addListener(object : Player.Listener {
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                if (playbackState == Player.STATE_READY && mediaType != CatalogType.LIVE) {
                                    playbackErrorMessage = ""
                                }
                            }

                            override fun onRenderedFirstFrame() {
                                firstFrameRendered = true
                                firstFrameFallbackJob?.cancel()
                                playbackErrorMessage = ""
                            }

                            override fun onPlayerError(error: PlaybackException) {
                                firstFrameFallbackJob?.cancel()
                                if (mediaType == CatalogType.LIVE) tryNextPlaybackSource()
                                else playbackErrorMessage = "No fue posible reproducir este contenido."
                            }
                        })
                        if (mediaType == CatalogType.LIVE) {
                            val initial = StreamItem(
                                id = selectedStreamId,
                                name = title,
                                image = "",
                                categoryId = "",
                                extension = url.substringAfterLast('.', "ts").substringBefore('?'),
                                description = "",
                                rating = "",
                                directSource = selectedDirectSource
                            )
                            startMediaCandidates(mediaController, buildLiveCandidates(initial, url), title)
                        } else {
                            startMedia(mediaController, url, title)
                        }
                    } catch (_: Exception) {
                        finish()
                    }
                },
                ContextCompat.getMainExecutor(this)
            )
        }
    }

    private fun loadLiveCatalog() {
        val activeSession = session ?: return
        listLoading = true
        lifecycleScope.launch {
            val cachedCategories = CatalogCache.loadCategories(
                this@PlayerActivity,
                activeSession,
                CatalogType.LIVE
            )
            val cachedItems = CatalogCache.loadItems(
                this@PlayerActivity,
                activeSession,
                CatalogType.LIVE
            )
            cachedCategories?.let { categoryNames = it.associate { category -> category.id to category.name } }
            cachedItems?.let { liveChannels = it }
            if (liveChannels.isNotEmpty()) {
                // No descargamos miles de canales justo mientras empieza el video.
                // El botón Actualizar del catálogo se encarga de traer cambios nuevos.
                listLoading = false
                return@launch
            }

            try {
                val categories = ApiClient.fetchCategories(activeSession, CatalogType.LIVE)
                categoryNames = categories.associate { it.id to it.name }
                CatalogCache.saveCategories(
                    this@PlayerActivity,
                    activeSession,
                    CatalogType.LIVE,
                    categories
                )

                val freshItems = ApiClient.fetchItems(activeSession, CatalogType.LIVE)
                liveChannels = freshItems
                CatalogCache.saveItems(
                    this@PlayerActivity,
                    activeSession,
                    CatalogType.LIVE,
                    freshItems
                )
            } catch (_: Exception) {
                // La reproducción continúa con la copia local si el servidor tarda.
            } finally {
                listLoading = false
            }
        }
    }

    private fun channelsForSelectedCategory(selected: StreamItem): List<StreamItem> {
        if (liveChannels.isEmpty()) return listOf(selected)
        val sameCategory = liveChannels.filter { it.categoryId == selected.categoryId }
        return if (sameCategory.isNotEmpty()) sameCategory else liveChannels
    }

    private fun playLiveChannel(channel: StreamItem) {
        selectedStreamId = channel.id
        selectedTitle = channel.name
        selectedDirectSource = channel.directSource
        val candidates = buildLiveCandidates(channel)
        saveMiniState(candidates.firstOrNull().orEmpty(), channel.directSource, channel.name, channel.id)
        controller?.let { startMediaCandidates(it, candidates, channel.name) }
        if (AppPreferences.epgEnabled(this)) loadEpg(channel.id)
    }

    private fun loadMovieNavigation() {
        val activeSession = session ?: return
        lifecycleScope.launch {
            val cached = CatalogCache.loadItems(this@PlayerActivity, activeSession, CatalogType.MOVIES)
            if (!cached.isNullOrEmpty()) {
                movieItems = cached
                return@launch
            }
            // Fallback de red solo si por alguna razón el catálogo no estaba cacheado.
            runCatching {
                val categories = ApiClient.fetchCategories(activeSession, CatalogType.MOVIES)
                ApiClient.fetchCatalogItems(activeSession, CatalogType.MOVIES, categories)
            }.getOrNull()?.takeIf { it.isNotEmpty() }?.let {
                movieItems = it
                CatalogCache.saveItems(this@PlayerActivity, activeSession, CatalogType.MOVIES, it)
            }
        }
    }

    private fun loadSeriesNavigation() {
        val activeSession = session ?: return
        if (parentSeriesId <= 0) return
        lifecycleScope.launch {
            CatalogCache.loadEpisodes(this@PlayerActivity, activeSession, parentSeriesId)
                ?.takeIf { it.isNotEmpty() }
                ?.let { seriesEpisodes = it }

            // Si ya tenemos episodios cacheados, la navegación anterior/siguiente
            // queda disponible al instante. Solo acudimos a red cuando no hay copia.
            if (seriesEpisodes.isNotEmpty()) return@launch

            runCatching { ApiClient.fetchSeriesEpisodes(activeSession, parentSeriesId) }
                .getOrNull()
                ?.takeIf { it.isNotEmpty() }
                ?.let {
                    seriesEpisodes = it
                    CatalogCache.saveEpisodes(this@PlayerActivity, activeSession, parentSeriesId, it)
                }
        }
    }

    private fun movieNavigationList(): List<StreamItem> {
        if (movieItems.isEmpty()) return emptyList()
        val current = movieItems.firstOrNull { it.id == selectedStreamId } ?: return movieItems
        val sameCategory = movieItems.filter { it.categoryId == current.categoryId }
        return if (sameCategory.isNotEmpty()) sameCategory else movieItems
    }

    private fun navigationSize(): Int = when (mediaType) {
        CatalogType.MOVIES -> movieNavigationList().size
        CatalogType.SERIES -> seriesEpisodes.size
        else -> 0
    }

    private fun playAdjacentContent(previous: Boolean): Boolean {
        val activeController = controller ?: return false
        return when (mediaType) {
            CatalogType.MOVIES -> {
                val items = movieNavigationList()
                if (items.size < 2) return false
                val currentIndex = items.indexOfFirst { it.id == selectedStreamId }.let { if (it < 0) 0 else it }
                val targetIndex = if (previous) (currentIndex - 1 + items.size) % items.size else (currentIndex + 1) % items.size
                val target = items[targetIndex]
                selectedStreamId = target.id
                selectedTitle = target.name
                selectedDirectSource = target.directSource
                val url = buildCatalogUrl(CatalogType.MOVIES, target.id, target.extension)
                saveMiniState(url, target.directSource, target.name, target.id)
                startMedia(activeController, url, target.name)
                true
            }
            CatalogType.SERIES -> {
                val episodes = seriesEpisodes
                if (episodes.size < 2) return false
                val currentIndex = episodes.indexOfFirst { it.id == selectedStreamId }.let { if (it < 0) 0 else it }
                val targetIndex = if (previous) (currentIndex - 1 + episodes.size) % episodes.size else (currentIndex + 1) % episodes.size
                val target = episodes[targetIndex]
                selectedStreamId = target.id
                selectedTitle = target.title
                selectedDirectSource = ""
                val url = buildCatalogUrl(CatalogType.SERIES, target.id, target.extension)
                saveMiniState(url, "", target.title, target.id)
                startMedia(activeController, url, target.title)
                true
            }
            else -> false
        }
    }

    private fun buildCatalogUrl(type: CatalogType, itemId: Int, extension: String): String {
        val activeSession = session ?: return ""
        val safeUser = Uri.encode(activeSession.username)
        val safePassword = Uri.encode(activeSession.password)
        val safeExtension = extension.ifBlank { if (type == CatalogType.LIVE) "ts" else "mp4" }
        return "${activeSession.baseUrl.trimEnd('/')}/${type.route}/$safeUser/$safePassword/$itemId.$safeExtension"
    }

    private fun saveMiniState(url: String, directSource: String, title: String, itemId: Int) {
        getSharedPreferences("fluxplay_mini", Context.MODE_PRIVATE).edit()
            .putString("url", url)
            .putString("direct", directSource)
            .putString("title", title)
            .putInt("id", itemId)
            .putString("type", mediaType.name)
            .putInt("parent_series_id", parentSeriesId)
            .apply()
    }

    private fun normalizeDirectSource(value: String): String {
        val cleaned = value.trim().replace("\\/", "/").replace("&amp;", "&")
        if (cleaned.isBlank()) return ""
        if (cleaned.startsWith("http://") || cleaned.startsWith("https://")) return cleaned
        val base = session?.baseUrl?.trimEnd('/').orEmpty()
        return if (cleaned.startsWith('/')) "$base$cleaned" else "$base/$cleaned"
    }

    private fun constructedLiveUrl(channel: StreamItem, extension: String): String {
        val activeSession = session ?: return ""
        val safeUser = Uri.encode(activeSession.username)
        val safePassword = Uri.encode(activeSession.password)
        return "${activeSession.baseUrl.trimEnd('/')}/live/$safeUser/$safePassword/${channel.id}.${extension.ifBlank { "ts" }}"
    }

    private fun buildLiveCandidates(channel: StreamItem, originalUrl: String = ""): List<String> {
        val direct = normalizeDirectSource(channel.directSource)
        val declared = channel.extension.ifBlank { "ts" }.lowercase(Locale.ROOT)
        val ts = constructedLiveUrl(channel, "ts")
        val hls = constructedLiveUrl(channel, "m3u8")
        val declaredUrl = constructedLiveUrl(channel, declared)
        val preferred = AppPreferences.streamFormat(this)

        // Respetamos la preferencia manual. En modo Automático priorizamos TS
        // para aprovechar el extractor tolerante y dejamos las otras variantes
        // como respaldo del mismo canal.
        val ordered = when (preferred) {
            "HLS (m3u8)" -> listOf(hls, declaredUrl, direct, ts, originalUrl)
            "MPEG-TS" -> listOf(ts, declaredUrl, direct, hls, originalUrl)
            "Fuente directa" -> listOf(direct, declaredUrl, ts, hls, originalUrl)
            // Automático: primero MPEG-TS porque ahí podemos usar el extractor
            // tolerante de Media3; si el servidor no lo acepta, cae enseguida a
            // la variante declarada/HLS/directa del mismo canal.
            else -> listOf(ts, declaredUrl, direct, originalUrl, hls)
        }
        return ordered.filter { it.isNotBlank() }.distinct()
    }

    private fun buildLiveUrl(channel: StreamItem): String = buildLiveCandidates(channel).firstOrNull().orEmpty()

    private fun loadEpg(streamId: Int) {
        if (!AppPreferences.epgEnabled(this)) return
        val activeSession = session ?: return
        epgLoading = true
        currentProgram = null
        nextProgram = null
        lifecycleScope.launch {
            try {
                val programs = ApiClient.fetchShortEpg(activeSession, streamId, 6)
                val nowSeconds = System.currentTimeMillis() / 1000L
                val activeIndex = programs.indexOfFirst {
                    it.startTimestamp > 0L && it.endTimestamp > 0L && nowSeconds in it.startTimestamp until it.endTimestamp
                }
                when {
                    activeIndex >= 0 -> {
                        currentProgram = programs[activeIndex]
                        nextProgram = programs.getOrNull(activeIndex + 1)
                    }
                    programs.isNotEmpty() -> {
                        val futureIndex = programs.indexOfFirst { it.startTimestamp >= nowSeconds }.let { if (it < 0) 0 else it }
                        currentProgram = programs.getOrNull(futureIndex)
                        nextProgram = programs.getOrNull(futureIndex + 1)
                    }
                }
            } catch (_: Exception) {
                currentProgram = null
                nextProgram = null
            } finally {
                epgLoading = false
            }
        }
    }

    private fun startMediaCandidates(mediaController: MediaController, candidates: List<String>, title: String) {
        playbackCandidates = candidates
        playbackCandidateIndex = 0
        playbackTitle = title
        switchingSource = false
        playbackErrorMessage = ""
        firstFrameRendered = false
        firstFrameFallbackJob?.cancel()
        val first = candidates.firstOrNull() ?: return
        startMedia(mediaController, first, title)
    }

    private fun tryNextPlaybackSource() {
        if (switchingSource) return
        if (playbackCandidateIndex >= playbackCandidates.lastIndex) {
            // No dejamos reproduciendo solamente el audio de una fuente que nunca
            // logró entregar cuadros de video.
            controller?.run {
                pause()
                stop()
                clearMediaItems()
            }
            playbackErrorMessage = "No fue posible reproducir la señal."
            return
        }
        switchingSource = true
        firstFrameRendered = false
        firstFrameFallbackJob?.cancel()
        playbackCandidateIndex += 1
        val nextUrl = playbackCandidates.getOrNull(playbackCandidateIndex)
        if (nextUrl == null) {
            controller?.run {
                pause()
                stop()
                clearMediaItems()
            }
            switchingSource = false
            playbackErrorMessage = "No fue posible reproducir la señal."
            return
        }
        controller?.let { startMedia(it, nextUrl, playbackTitle) }
        switchingSource = false
    }

    private fun startMedia(mediaController: MediaController, url: String, title: String) {
        if (url.isBlank()) return
        firstFrameFallbackJob?.cancel()
        firstFrameRendered = false
        playbackErrorMessage = ""
        val currentId = mediaController.currentMediaItem?.mediaId
        if (currentId != url) {
            // Corta por completo la fuente anterior antes de preparar la nueva.
            // Así no queda el audio del canal anterior sonando debajo de una señal
            // que falló o está cambiando de formato.
            mediaController.pause()
            mediaController.stop()
            val builder = MediaItem.Builder()
                .setMediaId(url)
                .setUri(url)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(title.ifBlank { "FluxPlay" })
                        .setArtist("FluxPlay")
                        .build()
                )
            inferMimeType(url)?.let { builder.setMimeType(it) }
            mediaController.setMediaItem(builder.build())
            mediaController.prepare()
        }
        mediaController.play()

        if (mediaType == CatalogType.LIVE && playbackCandidates.size > 1) {
            val expectedUrl = url
            firstFrameFallbackJob = lifecycleScope.launch {
                // Si llega audio pero ningún frame de video, pasamos a la siguiente
                // variante del mismo canal sin obligar al usuario a esperar.
                delay(4_000)
                val stillSame = controller?.currentMediaItem?.mediaId == expectedUrl
                if (stillSame && !firstFrameRendered) tryNextPlaybackSource()
            }
        }
    }

    private fun inferMimeType(url: String): String? {
        val clean = url.substringBefore('?').lowercase(Locale.ROOT)
        return when {
            clean.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
            clean.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            clean.endsWith(".mp4") || clean.endsWith(".m4v") -> MimeTypes.VIDEO_MP4
            clean.endsWith(".ts") || clean.endsWith(".mpegts") -> MimeTypes.VIDEO_MP2T
            else -> null
        }
    }

    private fun returnToCatalogWithMiniPlayer() {
        returningInsideApp = true
        MiniPlayerState.show()
        finish()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (returningInsideApp) return
        val player = controller
        if (AppPreferences.autoPip(this) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && player?.isPlaying == true) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
            )
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPictureInPicture = isInPictureInPictureMode
        if (!isInPictureInPictureMode) hideSystemUi()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    private fun stopPlaybackCompletely() {
        controller?.run {
            pause()
            stop()
            clearMediaItems()
        }
        MiniPlayerState.hide()
        stopService(Intent(this, PlaybackService::class.java))
    }

    override fun onDestroy() {
        firstFrameFallbackJob?.cancel()
        // Si el reproductor se está cerrando de verdad (no regresando al mini
        // reproductor y no en PiP), se elimina también el servicio multimedia.
        if (isFinishing && !returningInsideApp && !inPictureInPicture) {
            stopPlaybackCompletely()
        }
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "fluxplay_url"
        const val EXTRA_TITLE = "fluxplay_title"
        const val EXTRA_STREAM_ID = "fluxplay_stream_id"
        const val EXTRA_TYPE = "fluxplay_type"
        const val EXTRA_DIRECT_SOURCE = "fluxplay_direct_source"
        const val EXTRA_PARENT_SERIES_ID = "fluxplay_parent_series_id"
        const val EXTRA_START_FULLSCREEN = "fluxplay_start_fullscreen"
    }
}

@Composable
private fun LoadingPlayer() {
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(color = PlayerBlue)
    }
}

@Composable
private fun PictureInPictureVideo(player: Player) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    keepScreenOn = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                }
            },
            update = {
                it.useController = false
                it.player = player
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun VodPlayerDashboard(
    player: Player,
    title: String,
    mediaType: CatalogType,
    canNavigate: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit,
    onFullscreen: () -> Unit
) {
    var loading by remember { mutableStateOf(true) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loading = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(PlayerBackground)) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.34f
        )
        Box(Modifier.fillMaxSize().background(Color(0xB0030916)))

        val compact = maxHeight < 560.dp
        val pad = if (compact) 10.dp else 18.dp
        val gap = if (compact) 10.dp else 16.dp

        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(
                modifier = Modifier.fillMaxWidth().height(if (compact) 52.dp else 66.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(if (compact) 42.dp else 52.dp)) {
                    Icon(Icons.Default.ArrowBack, "Regresar", tint = Color.White, modifier = Modifier.size(if (compact) 29.dp else 36.dp))
                }
                Image(
                    painter = painterResource(R.drawable.fluxplay_logo),
                    contentDescription = "FluxPlay",
                    modifier = Modifier.width(if (compact) 90.dp else 120.dp).height(if (compact) 44.dp else 58.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    if (mediaType == CatalogType.SERIES) "| Series" else "| Películas",
                    color = Color.White,
                    fontSize = if (compact) 19.sp else 25.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "Doble clic para ampliar",
                    color = PlayerMuted,
                    fontSize = if (compact) 12.sp else 15.sp
                )
            }

            Spacer(Modifier.height(gap))

            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1.75f)
                        .clip(RoundedCornerShape(if (compact) 12.dp else 18.dp))
                        .background(Color.Black)
                        .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 12.dp else 18.dp))
                ) {
                    AndroidView(
                        factory = { context ->
                            PlayerView(context).apply {
                                useController = false
                                keepScreenOn = true
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                this.player = player
                            }
                        },
                        update = {
                            it.useController = false
                            it.player = player
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Capa táctil: un toque no cambia la pantalla; dos toques la amplían.
                    Box(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(title) {
                                detectTapGestures(onDoubleTap = { onFullscreen() })
                            }
                    )

                    if (loading) {
                        CircularProgressIndicator(color = PlayerBlue, modifier = Modifier.align(Alignment.Center))
                    }

                    IconButton(
                        onClick = onFullscreen,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .size(if (compact) 44.dp else 54.dp)
                            .clip(CircleShape)
                            .background(Color(0xC0000000))
                    ) {
                        Icon(Icons.Default.Fullscreen, "Pantalla completa", tint = Color.White, modifier = Modifier.size(if (compact) 28.dp else 35.dp))
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(0.72f)
                        .clip(RoundedCornerShape(if (compact) 12.dp else 18.dp))
                        .background(PlayerPanel)
                        .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 12.dp else 18.dp))
                        .padding(if (compact) 14.dp else 20.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        if (mediaType == CatalogType.SERIES) "EPISODIO" else "PELÍCULA",
                        color = PlayerBlue,
                        fontSize = if (compact) 12.sp else 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        title,
                        color = Color.White,
                        fontSize = if (compact) 20.sp else 27.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(if (compact) 14.dp else 22.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onPrevious, enabled = canNavigate) {
                            Icon(Icons.Default.SkipPrevious, "Anterior", tint = if (canNavigate) Color.White else PlayerMuted, modifier = Modifier.size(36.dp))
                        }
                        IconButton(
                            onClick = { if (player.isPlaying) player.pause() else player.play() },
                            modifier = Modifier.size(if (compact) 54.dp else 64.dp).clip(CircleShape).background(Color.White)
                        ) {
                            Icon(
                                if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                "Pausa",
                                tint = Color.Black,
                                modifier = Modifier.size(if (compact) 36.dp else 44.dp)
                            )
                        }
                        IconButton(onClick = onNext, enabled = canNavigate) {
                            Icon(Icons.Default.SkipNext, "Siguiente", tint = if (canNavigate) Color.White else PlayerMuted, modifier = Modifier.size(36.dp))
                        }
                    }
                    Spacer(Modifier.height(if (compact) 12.dp else 20.dp))
                    Text(
                        if (mediaType == CatalogType.SERIES) {
                            "▲ episodio anterior  •  ▼ episodio siguiente"
                        } else {
                            "▲ película anterior  •  ▼ película siguiente"
                        },
                        color = PlayerMuted,
                        fontSize = if (compact) 11.sp else 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Doble clic sobre el video para pantalla completa. Retroceder vuelve a esta vista.",
                        color = Color.White.copy(alpha = .78f),
                        fontSize = if (compact) 11.sp else 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun FullScreenVodPlayer(
    player: Player,
    title: String,
    mediaType: CatalogType,
    canNavigate: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onExit: () -> Unit
) {
    var loading by remember { mutableStateOf(true) }
    var controlsVisible by remember { mutableStateOf(true) }

    BackHandler(onBack = onExit)

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loading = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(controlsVisible) {
        if (controlsVisible) {
            delay(4_500)
            controlsVisible = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    keepScreenOn = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                }
            },
            update = {
                it.useController = false
                it.player = player
            },
            modifier = Modifier.fillMaxSize()
        )

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(title) {
                    detectTapGestures(
                        onTap = { controlsVisible = true },
                        onDoubleTap = { onExit() }
                    )
                }
        )

        if (loading) {
            CircularProgressIndicator(color = PlayerBlue, modifier = Modifier.align(Alignment.Center))
        }

        if (controlsVisible) {
            Box(Modifier.fillMaxSize().background(Color(0x45000000)))
            Row(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onExit,
                    modifier = Modifier.size(54.dp).clip(CircleShape).background(PlayerPurple)
                ) {
                    Icon(Icons.Default.FullscreenExit, "Volver a pantalla pequeña", tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(14.dp))
                Text(
                    title,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(34.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onPrevious,
                    enabled = canNavigate,
                    modifier = Modifier.size(68.dp).clip(CircleShape).background(Color(0xC8222940))
                ) {
                    Icon(
                        Icons.Default.SkipPrevious,
                        if (mediaType == CatalogType.SERIES) "Episodio anterior" else "Película anterior",
                        tint = if (canNavigate) Color.White else PlayerMuted,
                        modifier = Modifier.size(48.dp)
                    )
                }
                IconButton(
                    onClick = { if (player.isPlaying) player.pause() else player.play() },
                    modifier = Modifier.size(78.dp).clip(CircleShape).background(Color.White)
                ) {
                    Icon(
                        if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Pausa",
                        tint = Color.Black,
                        modifier = Modifier.size(52.dp)
                    )
                }
                IconButton(
                    onClick = onNext,
                    enabled = canNavigate,
                    modifier = Modifier.size(68.dp).clip(CircleShape).background(Color(0xC8222940))
                ) {
                    Icon(
                        Icons.Default.SkipNext,
                        if (mediaType == CatalogType.SERIES) "Episodio siguiente" else "Película siguiente",
                        tint = if (canNavigate) Color.White else PlayerMuted,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Text(
                text = if (mediaType == CatalogType.SERIES) {
                    "▲ Episodio anterior   •   ▼ Episodio siguiente   •   Atrás: pantalla pequeña"
                } else {
                    "▲ Película anterior   •   ▼ Película siguiente   •   Atrás: pantalla pequeña"
                },
                color = Color.White.copy(alpha = .82f),
                fontSize = 14.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp)
            )
        }
    }
}

@Composable
private fun FullScreenLivePlayer(
    player: Player,
    selected: StreamItem,
    channels: List<StreamItem>,
    currentProgram: EpgProgram?,
    nextProgram: EpgProgram?,
    epgLoading: Boolean,
    buildStreamUrl: (StreamItem) -> String,
    onSelectChannel: (StreamItem) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var brightness by remember {
        mutableStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.72f)
    }
    var controlsVisible by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var resizeMode by remember {
        mutableStateOf(
            when (AppPreferences.aspectMode(context)) {
                "Rellenar" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                "Zoom" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        )
    }
    var showChannelList by remember { mutableStateOf(false) }
    var showMultiPicker by remember { mutableStateOf(false) }
    var secondaryChannel by remember { mutableStateOf<StreamItem?>(null) }
    var secondaryPlayer by remember { mutableStateOf<ExoPlayer?>(null) }

    BackHandler(onBack = onExit)

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loading = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    DisposableEffect(Unit) {
        onDispose { secondaryPlayer?.release() }
    }

    LaunchedEffect(controlsVisible, locked, showChannelList, showMultiPicker) {
        if (controlsVisible && !locked && !showChannelList && !showMultiPicker) {
            delay(5_000)
            controlsVisible = false
        }
    }

    fun playSecondary(channel: StreamItem) {
        val url = buildStreamUrl(channel)
        if (url.isBlank()) return
        val p = secondaryPlayer ?: ExoPlayer.Builder(context).build().also { secondaryPlayer = it }
        p.volume = 0f
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.play()
        secondaryChannel = channel
        showMultiPicker = false
        controlsVisible = true
    }

    val index = channels.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
    fun previousChannel() { if (channels.isNotEmpty()) onSelectChannel(channels[(index - 1 + channels.size) % channels.size]) }
    fun nextChannel() { if (channels.isNotEmpty()) onSelectChannel(channels[(index + 1) % channels.size]) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { controlsVisible = true }
    ) {
        Row(Modifier.fillMaxSize()) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        keepScreenOn = true
                        this.resizeMode = resizeMode
                        this.player = player
                    }
                },
                update = {
                    it.useController = false
                    it.resizeMode = resizeMode
                    it.player = player
                },
                modifier = Modifier.fillMaxHeight().weight(1f)
            )
            val second = secondaryPlayer
            if (second != null && secondaryChannel != null) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            keepScreenOn = true
                            this.resizeMode = resizeMode
                            this.player = second
                        }
                    },
                    update = {
                        it.useController = false
                        it.resizeMode = resizeMode
                        it.player = second
                    },
                    modifier = Modifier.fillMaxHeight().weight(1f)
                )
            }
        }

        if (loading) CircularProgressIndicator(color = PlayerBlue, modifier = Modifier.align(Alignment.Center))

        Box(
            Modifier
                .fillMaxSize()
                .clickable { controlsVisible = true }
        )

        if (controlsVisible || locked) {
            Box(Modifier.fillMaxSize().background(Color(0x52000000)))

            if (locked) {
                IconButton(
                    onClick = { locked = false; controlsVisible = true },
                    modifier = Modifier.align(Alignment.Center).size(74.dp).clip(CircleShape).background(Color(0xD0202440))
                ) {
                    Icon(Icons.Default.Lock, "Desbloquear", tint = Color.White, modifier = Modifier.size(42.dp))
                }
            } else {
                Row(
                    modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onExit, modifier = Modifier.size(54.dp).clip(CircleShape).background(PlayerPurple)) {
                        Icon(Icons.Default.ArrowBack, "Regresar", tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(selected.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_CAST_SETTINGS)) }
                            .onFailure { Toast.makeText(context, "No hay opciones de transmisión disponibles", Toast.LENGTH_SHORT).show() }
                    }) { Icon(Icons.Default.Cast, "Transmitir", tint = Color.White, modifier = Modifier.size(34.dp)) }
                    IconButton(onClick = { locked = true }) { Icon(Icons.Default.LockOpen, "Bloquear", tint = Color.White, modifier = Modifier.size(34.dp)) }
                    IconButton(onClick = {
                        resizeMode = when (resizeMode) {
                            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    }, modifier = Modifier.size(54.dp).clip(CircleShape).background(PlayerPurple)) {
                        Icon(Icons.Default.Settings, "Ajustes", tint = Color.White, modifier = Modifier.size(31.dp))
                    }
                }

                FullscreenVerticalSlider(
                    value = brightness,
                    maxValue = 1f,
                    icon = Icons.Default.Brightness6,
                    modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp),
                    onValueChange = { value ->
                        brightness = value
                        activity?.window?.let { window ->
                            val params = window.attributes
                            params.screenBrightness = value.coerceIn(0.05f, 1f)
                            window.attributes = params
                        }
                    }
                )
                FullscreenVerticalSlider(
                    value = volume,
                    maxValue = maxVolume.toFloat(),
                    icon = Icons.Default.VolumeUp,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp),
                    onValueChange = { value ->
                        volume = value
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value.toInt(), 0)
                    }
                )

                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { previousChannel() }, modifier = Modifier.size(62.dp)) { Icon(Icons.Default.SkipPrevious, "Canal anterior", tint = Color.White, modifier = Modifier.size(54.dp)) }
                    IconButton(onClick = { player.seekBack() }, modifier = Modifier.size(58.dp)) { Icon(Icons.Default.Replay10, "Retroceder", tint = Color.White, modifier = Modifier.size(48.dp)) }
                    IconButton(
                        onClick = { if (player.isPlaying) player.pause() else player.play() },
                        modifier = Modifier.size(76.dp).clip(CircleShape).background(Color.White)
                    ) { Icon(if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Pausa", tint = Color.Black, modifier = Modifier.size(50.dp)) }
                    IconButton(onClick = { player.seekForward() }, modifier = Modifier.size(58.dp)) { Icon(Icons.Default.Forward10, "Adelantar", tint = Color.White, modifier = Modifier.size(48.dp)) }
                    IconButton(onClick = { nextChannel() }, modifier = Modifier.size(62.dp)) { Icon(Icons.Default.SkipNext, "Canal siguiente", tint = Color.White, modifier = Modifier.size(54.dp)) }
                }

                Column(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 120.dp, end = 120.dp, bottom = 14.dp)
                ) {
                    val currentTitle = when {
                        epgLoading -> "Cargando programación…"
                        currentProgram != null -> currentProgram.title
                        else -> "Programación no disponible"
                    }
                    Text("Ahora: $currentTitle", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("Siguiente: ${nextProgram?.title ?: "Programación no disponible"}", color = Color.White.copy(alpha = .84f), fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(4.dp).background(Color.White.copy(alpha = .32f))) {
                        Box(Modifier.fillMaxWidth(epgProgress(currentProgram)).fillMaxHeight().background(PlayerBlue))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        FullscreenAction(Icons.Default.List, "Lista de canales") { showChannelList = true }
                        FullscreenAction(Icons.Default.AspectRatio, "Relación de aspecto") {
                            resizeMode = when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                        }
                        FullscreenAction(Icons.Default.GridView, if (secondaryPlayer == null) "Pantalla múltiple" else "Cerrar pantalla múltiple") {
                            if (secondaryPlayer != null) {
                                secondaryPlayer?.release(); secondaryPlayer = null; secondaryChannel = null
                            } else {
                                showMultiPicker = true
                            }
                        }
                    }
                }
            }
        }

        if (showChannelList || showMultiPicker) {
            Box(Modifier.fillMaxSize().background(Color(0xC8000000))) {
                Column(
                    Modifier.align(Alignment.CenterStart).fillMaxHeight().width(420.dp).background(PlayerPanel).padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (showMultiPicker) "Elegir segundo canal" else "Lista de canales", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { showChannelList = false; showMultiPicker = false }) {
                            Icon(Icons.Default.ArrowBack, "Cerrar", tint = Color.White)
                        }
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(channels, key = { it.id }) { channel ->
                            ChannelListRow(
                                channel = channel,
                                selected = channel.id == selected.id,
                                compact = true,
                                requestInitialFocus = channel.id == selected.id,
                                onClick = {
                                    if (showMultiPicker) playSecondary(channel)
                                    else { onSelectChannel(channel); showChannelList = false }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FullscreenVerticalSlider(
    value: Float,
    maxValue: Float,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onValueChange: (Float) -> Unit
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(12.dp))
        Slider(
            value = value.coerceIn(0f, maxValue),
            onValueChange = onValueChange,
            valueRange = 0f..maxValue,
            modifier = Modifier.width(210.dp).rotate(-90f)
        )
    }
}

@Composable
private fun FullscreenAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(27.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}

private fun epgProgress(program: EpgProgram?): Float {
    if (program == null || program.startTimestamp <= 0L || program.endTimestamp <= program.startTimestamp) return 0.08f
    val now = System.currentTimeMillis() / 1000L
    return ((now - program.startTimestamp).toFloat() / (program.endTimestamp - program.startTimestamp).toFloat()).coerceIn(0f, 1f)
}

@Composable
private fun LivePlayerDashboard(
    player: Player,
    selected: StreamItem,
    channels: List<StreamItem>,
    categoryTitle: String,
    loadingChannels: Boolean,
    currentProgram: EpgProgram?,
    nextProgram: EpgProgram?,
    epgLoading: Boolean,
    playbackError: String,
    onBack: () -> Unit,
    onFullscreen: () -> Unit,
    onSelectChannel: (StreamItem) -> Unit
) {
    val context = LocalContext.current
    var loadingVideo by remember { mutableStateOf(true) }
    var now by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loadingVideo = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }

            override fun onPlayerError(error: PlaybackException) {
                // PlayerActivity prueba inmediatamente la siguiente fuente.
                // No mostramos un error transitorio que desaparece cuando el fallback funciona.
                loadingVideo = true
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PlayerBackground)
    ) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.42f
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color(0xE8030916)),
                    radius = 1350f
                )
            )
        )

        val compact = maxHeight < 600.dp
        val pagePadding = if (compact) 10.dp else 18.dp
        val headerHeight = if (compact) 56.dp else 72.dp
        val paneGap = if (compact) 10.dp else 16.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = pagePadding, vertical = if (compact) 6.dp else 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(headerHeight),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(if (compact) 42.dp else 54.dp)) {
                    Icon(Icons.Default.ArrowBack, "Regresar", tint = Color.White, modifier = Modifier.size(if (compact) 29.dp else 38.dp))
                }
                Image(
                    painter = painterResource(R.drawable.fluxplay_logo),
                    contentDescription = "FluxPlay",
                    modifier = Modifier.width(if (compact) 90.dp else 122.dp).height(headerHeight - 8.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(if (compact) 12.dp else 22.dp))
                Text("| Live", color = Color.White, fontSize = if (compact) 20.sp else 27.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                val timePattern = if (AppPreferences.timeFormat(context) == "24 horas") "HH:mm" else "hh:mm a"
                Text(
                    SimpleDateFormat(timePattern, Locale.getDefault()).format(now),
                    fontSize = if (compact) 18.sp else 25.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(Modifier.width(if (compact) 12.dp else 20.dp))
                Text(
                    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(now),
                    color = PlayerMuted,
                    fontSize = if (compact) 13.sp else 18.sp
                )
                Spacer(Modifier.width(if (compact) 12.dp else 20.dp))
                Icon(Icons.Default.Search, "Buscar", tint = Color.White, modifier = Modifier.size(if (compact) 28.dp else 38.dp))
                Spacer(Modifier.width(if (compact) 6.dp else 12.dp))
                Icon(Icons.Default.MoreVert, "Más", tint = Color.White, modifier = Modifier.size(if (compact) 28.dp else 38.dp))
            }

            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(paneGap)
            ) {
                ChannelListPanel(
                    selected = selected,
                    channels = channels,
                    categoryTitle = categoryTitle,
                    loading = loadingChannels,
                    currentProgram = currentProgram,
                    compact = compact,
                    modifier = Modifier.fillMaxHeight().weight(0.82f),
                    onSelect = onSelectChannel,
                    onFullscreen = onFullscreen
                )

                Column(
                    modifier = Modifier.fillMaxHeight().weight(1.45f),
                    verticalArrangement = Arrangement.spacedBy(paneGap)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().weight(1.05f),
                        horizontalArrangement = Arrangement.spacedBy(paneGap)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .weight(1.55f)
                                .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
                                .background(Color.Black)
                                .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
                        ) {
                            AndroidView(
                                factory = { context ->
                                    PlayerView(context).apply {
                                        useController = false
                                        keepScreenOn = true
                                        resizeMode = when (AppPreferences.aspectMode(context)) {
                                            "Rellenar" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                            "Zoom" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        }
                                        this.player = player
                                    }
                                },
                                update = {
                                    it.useController = false
                                    it.player = player
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .pointerInput(selected.id) {
                                        detectTapGestures(onDoubleTap = { onFullscreen() })
                                    }
                            )
                            if (loadingVideo) {
                                CircularProgressIndicator(
                                    color = PlayerBlue,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            if (playbackError.isNotBlank()) {
                                Text(
                                    playbackError,
                                    color = Color(0xFFFF9BAD),
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .background(Color(0xCC160812))
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                            IconButton(
                                onClick = onFullscreen,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .size(if (compact) 42.dp else 50.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xB3000000))
                            ) {
                                Icon(
                                    Icons.Default.Fullscreen,
                                    contentDescription = "Pantalla completa",
                                    tint = Color.White,
                                    modifier = Modifier.size(if (compact) 26.dp else 33.dp)
                                )
                            }
                        }

                        CurrentChannelPanel(
                            selected = selected,
                            compact = compact,
                            modifier = Modifier.fillMaxHeight().weight(0.72f)
                        )
                    }

                    GuidePanel(
                        selected = selected,
                        currentProgram = currentProgram,
                        nextProgram = nextProgram,
                        loading = epgLoading,
                        compact = compact,
                        modifier = Modifier.fillMaxWidth().weight(0.95f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelListPanel(
    selected: StreamItem,
    channels: List<StreamItem>,
    categoryTitle: String,
    loading: Boolean,
    currentProgram: EpgProgram?,
    compact: Boolean,
    modifier: Modifier,
    onSelect: (StreamItem) -> Unit,
    onFullscreen: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE8071327))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 48.dp else 64.dp)
                .background(Color(0xEE061020))
                .padding(horizontal = if (compact) 10.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.ArrowBackIosNew, null, tint = Color.White, modifier = Modifier.size(if (compact) 19.dp else 25.dp))
            Spacer(Modifier.weight(1f))
            Text(
                categoryTitle,
                fontSize = if (compact) 15.sp else 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ArrowForwardIos, null, tint = Color.White, modifier = Modifier.size(if (compact) 19.dp else 25.dp))
        }

        if (loading && channels.size <= 1) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PlayerBlue)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(channels, key = { it.id }) { channel ->
                    ChannelListRow(
                        channel = channel,
                        selected = channel.id == selected.id,
                        compact = compact,
                        guideText = if (channel.id == selected.id) currentProgram?.title.orEmpty() else "",
                        requestInitialFocus = channel.id == selected.id,
                        onClick = { onSelect(channel) },
                        onDoubleClick = {
                            onSelect(channel)
                            onFullscreen()
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChannelListRow(
    channel: StreamItem,
    selected: Boolean,
    compact: Boolean,
    guideText: String = "",
    requestInitialFocus: Boolean = false,
    onClick: () -> Unit,
    onDoubleClick: (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    val active = selected || focused

    LaunchedEffect(requestInitialFocus, channel.id) {
        if (requestInitialFocus) {
            delay(120)
            runCatching { focusRequester.requestFocus() }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .onFocusChanged { focused = it.isFocused }
            .background(if (active) PlayerPurple else Color.Transparent)
            .border(
                if (focused) 2.dp else 0.5.dp,
                if (focused) Color.White else Color(0x553A5277),
                RoundedCornerShape(1.dp)
            )
            .combinedClickable(onClick = onClick, onDoubleClick = onDoubleClick)
            .focusable()
            .padding(horizontal = if (compact) 8.dp else 11.dp, vertical = if (compact) 5.dp else 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            channel.id.toString(),
            modifier = Modifier.width(if (compact) 36.dp else 48.dp),
            fontSize = if (compact) 11.sp else 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        AsyncImage(
            model = channel.image,
            contentDescription = null,
            modifier = Modifier
                .size(if (compact) 38.dp else 52.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(Color.White),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.width(if (compact) 8.dp else 11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                channel.name,
                fontSize = if (compact) 12.sp else 16.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                guideText.ifBlank { "No se encontró ningún programa" },
                color = if (active) Color.White.copy(alpha = 0.86f) else PlayerMuted,
                fontSize = if (compact) 9.sp else 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CurrentChannelPanel(selected: StreamItem, compact: Boolean, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE7071429))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .padding(if (compact) 12.dp else 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AsyncImage(
            model = selected.image,
            contentDescription = null,
            modifier = Modifier
                .size(if (compact) 52.dp else 76.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
        Text(
            "TV EN DIRECTO",
            color = Color.White,
            fontSize = if (compact) 11.sp else 15.sp,
            modifier = Modifier
                .background(PlayerPurple)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(
            selected.name,
            fontSize = if (compact) 15.sp else 21.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GuidePanel(
    selected: StreamItem,
    currentProgram: EpgProgram?,
    nextProgram: EpgProgram?,
    loading: Boolean,
    compact: Boolean,
    modifier: Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE7071429))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .padding(if (compact) 14.dp else 20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "GUÍA DEL CANAL",
            color = PlayerBlue,
            fontSize = if (compact) 12.sp else 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(
            "Ahora: ${if (loading) "Cargando programación…" else currentProgram?.title ?: "Programación no disponible"}",
            fontSize = if (compact) 14.sp else 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (!currentProgram?.description.isNullOrBlank()) {
            Text(
                currentProgram?.description.orEmpty(),
                color = PlayerMuted,
                fontSize = if (compact) 10.sp else 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.height(if (compact) 5.dp else 8.dp))
        Text(
            "Siguiente: ${nextProgram?.title ?: "Programación no disponible"}",
            color = PlayerMuted,
            fontSize = if (compact) 12.sp else 17.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Box(
            Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color(0xFF50647F))
        ) {
            Box(
                Modifier.fillMaxWidth(epgProgress(currentProgram)).fillMaxHeight().background(PlayerBlue)
            )
        }
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(selected.name, color = Color.White, fontSize = if (compact) 11.sp else 15.sp)
    }
}

