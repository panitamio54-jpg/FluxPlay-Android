package com.fluxplay.app

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture

class PlayerActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )

        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        if (url.isBlank()) {
            finish()
            return
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color.Black,
                    surface = Color.Black,
                    primary = Color(0xFF198BFF)
                )
            ) {
                val activeController = controller
                if (activeController == null) {
                    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFF198BFF))
                    }
                } else {
                    PlayerContent(player = activeController, title = title)
                }
            }
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener(
                {
                    try {
                        val mediaController = future.get()
                        controller = mediaController
                        val currentId = mediaController.currentMediaItem?.mediaId
                        if (currentId != url) {
                            val mediaItem = MediaItem.Builder()
                                .setMediaId(url)
                                .setUri(url)
                                .setMediaMetadata(
                                    MediaMetadata.Builder()
                                        .setTitle(title.ifBlank { "FluxPlay" })
                                        .setArtist("FluxPlay")
                                        .build()
                                )
                                .build()
                            mediaController.setMediaItem(mediaItem)
                            mediaController.prepare()
                            mediaController.play()
                        } else if (!mediaController.isPlaying) {
                            mediaController.play()
                        }
                    } catch (_: Exception) {
                        finish()
                    }
                },
                ContextCompat.getMainExecutor(this)
            )
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val player = controller
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && player?.isPlaying == true) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
            )
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "fluxplay_url"
        const val EXTRA_TITLE = "fluxplay_title"
    }
}

@androidx.compose.runtime.Composable
private fun PlayerContent(player: Player, title: String) {
    var loading by androidx.compose.runtime.remember { mutableStateOf(true) }
    var errorMessage by androidx.compose.runtime.remember { mutableStateOf("") }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loading = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }

            override fun onPlayerError(error: PlaybackException) {
                loading = false
                errorMessage = error.localizedMessage ?: "No fue posible reproducir esta señal."
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    useController = true
                    keepScreenOn = true
                    this.player = player
                }
            },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )

        if (title.isNotBlank()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(title, color = Color.White, fontSize = 18.sp)
                Text(
                    "El video continuará en segundo plano o en ventana flotante.",
                    color = Color(0xFFB9C8DA),
                    fontSize = 11.sp
                )
            }
        }

        if (loading) {
            CircularProgressIndicator(
                color = Color(0xFF198BFF),
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (errorMessage.isNotBlank()) {
            Text(
                errorMessage,
                color = Color(0xFFFF91A4),
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xDD120711))
                    .padding(18.dp)
            )
        }
    }
}
