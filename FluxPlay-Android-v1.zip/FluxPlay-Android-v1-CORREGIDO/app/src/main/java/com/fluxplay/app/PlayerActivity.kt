package com.fluxplay.app

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PlayerBlue = Color(0xFF198BFF)
private val PlayerPurple = Color(0xFF5A38B7)
private val PlayerBackground = Color(0xFF030A18)
private val PlayerPanel = Color(0xE70A1730)
private val PlayerLine = Color(0xFF29446D)
private val PlayerMuted = Color(0xFFA9B8CE)

class PlayerActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)
    private var liveChannels by mutableStateOf<List<StreamItem>>(emptyList())
    private var categoryNames by mutableStateOf<Map<String, String>>(emptyMap())
    private var selectedStreamId by mutableStateOf(0)
    private var selectedTitle by mutableStateOf("")
    private var listLoading by mutableStateOf(false)
    private var inPictureInPicture by mutableStateOf(false)
    private var mediaType = CatalogType.LIVE
    private var session: Session? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        selectedTitle = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        selectedStreamId = intent.getIntExtra(EXTRA_STREAM_ID, 0)
        mediaType = runCatching {
            CatalogType.valueOf(intent.getStringExtra(EXTRA_TYPE).orEmpty())
        }.getOrDefault(CatalogType.LIVE)
        session = SessionManager.load(this)

        if (url.isBlank()) {
            finish()
            return
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color.Black,
                    surface = PlayerPanel,
                    primary = PlayerBlue
                )
            ) {
                val activeController = controller
                when {
                    activeController == null -> LoadingPlayer()
                    inPictureInPicture || mediaType != CatalogType.LIVE -> VideoOnlyPlayer(activeController)
                    else -> {
                        val selected = liveChannels.firstOrNull { it.id == selectedStreamId }
                            ?: StreamItem(
                                id = selectedStreamId,
                                name = selectedTitle.ifBlank { "Canal en vivo" },
                                image = "",
                                categoryId = "",
                                extension = "ts",
                                description = "",
                                rating = ""
                            )
                        LivePlayerDashboard(
                            player = activeController,
                            selected = selected,
                            channels = channelsForSelectedCategory(selected),
                            categoryTitle = categoryNames[selected.categoryId] ?: "TV EN VIVO",
                            loadingChannels = listLoading,
                            onBack = { finish() },
                            onSelectChannel = { playLiveChannel(it) }
                        )
                    }
                }
            }
        }

        connectController(url, selectedTitle)
        if (mediaType == CatalogType.LIVE) loadLiveCatalog()
    }

    private fun connectController(url: String, title: String) {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener(
                {
                    try {
                        val mediaController = future.get()
                        controller = mediaController
                        startMedia(mediaController, url, title)
                    } catch (_: Exception) {
                        finish()
                    }
                },
                ContextCompat.getMainExecutor(this)
            )
        }
    }

    private fun loadLiveCatalog() {
        val activeSession = session ?: return
        listLoading = true
        lifecycleScope.launch {
            try {
                val categories = ApiClient.fetchCategories(activeSession, CatalogType.LIVE)
                categoryNames = categories.associate { it.id to it.name }
                liveChannels = ApiClient.fetchItems(activeSession, CatalogType.LIVE)
            } catch (_: Exception) {
                // La reproducción continúa aunque el listado no se pueda actualizar.
            } finally {
                listLoading = false
            }
        }
    }

    private fun channelsForSelectedCategory(selected: StreamItem): List<StreamItem> {
        if (liveChannels.isEmpty()) return listOf(selected)
        val sameCategory = liveChannels.filter { it.categoryId == selected.categoryId }
        return if (sameCategory.isNotEmpty()) sameCategory else liveChannels
    }

    private fun playLiveChannel(channel: StreamItem) {
        val activeSession = session ?: return
        selectedStreamId = channel.id
        selectedTitle = channel.name
        val safeUser = Uri.encode(activeSession.username)
        val safePassword = Uri.encode(activeSession.password)
        val extension = channel.extension.ifBlank { "ts" }
        val url = "${activeSession.baseUrl.trimEnd('/')}/live/$safeUser/$safePassword/${channel.id}.$extension"
        controller?.let { startMedia(it, url, channel.name) }
    }

    private fun startMedia(mediaController: MediaController, url: String, title: String) {
        val currentId = mediaController.currentMediaItem?.mediaId
        if (currentId != url) {
            val mediaItem = MediaItem.Builder()
                .setMediaId(url)
                .setUri(url)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(title.ifBlank { "FluxPlay" })
                        .setArtist("FluxPlay")
                        .build()
                )
                .build()
            mediaController.setMediaItem(mediaItem)
            mediaController.prepare()
        }
        mediaController.play()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val player = controller
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && player?.isPlaying == true) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
            )
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPictureInPicture = isInPictureInPictureMode
        if (!isInPictureInPictureMode) hideSystemUi()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "fluxplay_url"
        const val EXTRA_TITLE = "fluxplay_title"
        const val EXTRA_STREAM_ID = "fluxplay_stream_id"
        const val EXTRA_TYPE = "fluxplay_type"
    }
}

@Composable
private fun LoadingPlayer() {
    Box(
        Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(color = PlayerBlue)
    }
}

@Composable
private fun VideoOnlyPlayer(player: Player) {
    var loading by remember { mutableStateOf(true) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loading = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    keepScreenOn = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                }
            },
            update = {
                it.useController = false
                it.player = player
            },
            modifier = Modifier.fillMaxSize()
        )
        if (loading) {
            CircularProgressIndicator(
                color = PlayerBlue,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun LivePlayerDashboard(
    player: Player,
    selected: StreamItem,
    channels: List<StreamItem>,
    categoryTitle: String,
    loadingChannels: Boolean,
    onBack: () -> Unit,
    onSelectChannel: (StreamItem) -> Unit
) {
    var loadingVideo by remember { mutableStateOf(true) }
    var playbackError by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                loadingVideo = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
            }

            override fun onPlayerError(error: PlaybackException) {
                loadingVideo = false
                playbackError = "No fue posible reproducir la señal."
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PlayerBackground)
    ) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.42f
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color(0xE8030916)),
                    radius = 1350f
                )
            )
        )

        val compact = maxHeight < 600.dp
        val pagePadding = if (compact) 10.dp else 18.dp
        val headerHeight = if (compact) 56.dp else 72.dp
        val paneGap = if (compact) 10.dp else 16.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = pagePadding, vertical = if (compact) 6.dp else 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(headerHeight),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(if (compact) 42.dp else 54.dp)) {
                    Icon(Icons.Default.ArrowBack, "Regresar", modifier = Modifier.size(if (compact) 29.dp else 38.dp))
                }
                Image(
                    painter = painterResource(R.drawable.fluxplay_logo),
                    contentDescription = "FluxPlay",
                    modifier = Modifier.width(if (compact) 90.dp else 122.dp).height(headerHeight - 8.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(if (compact) 12.dp else 22.dp))
                Text("| Live", fontSize = if (compact) 20.sp else 27.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Text(
                    SimpleDateFormat("hh:mm a", Locale.getDefault()).format(now),
                    fontSize = if (compact) 18.sp else 25.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(if (compact) 12.dp else 20.dp))
                Text(
                    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(now),
                    color = PlayerMuted,
                    fontSize = if (compact) 13.sp else 18.sp
                )
                Spacer(Modifier.width(if (compact) 12.dp else 20.dp))
                Icon(Icons.Default.Search, "Buscar", modifier = Modifier.size(if (compact) 28.dp else 38.dp))
                Spacer(Modifier.width(if (compact) 6.dp else 12.dp))
                Icon(Icons.Default.MoreVert, "Más", modifier = Modifier.size(if (compact) 28.dp else 38.dp))
            }

            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(paneGap)
            ) {
                ChannelListPanel(
                    selected = selected,
                    channels = channels,
                    categoryTitle = categoryTitle,
                    loading = loadingChannels,
                    compact = compact,
                    modifier = Modifier.fillMaxHeight().weight(0.82f),
                    onSelect = onSelectChannel
                )

                Column(
                    modifier = Modifier.fillMaxHeight().weight(1.45f),
                    verticalArrangement = Arrangement.spacedBy(paneGap)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().weight(1.05f),
                        horizontalArrangement = Arrangement.spacedBy(paneGap)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .weight(1.55f)
                                .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
                                .background(Color.Black)
                                .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
                        ) {
                            AndroidView(
                                factory = { context ->
                                    PlayerView(context).apply {
                                        useController = true
                                        keepScreenOn = true
                                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                        this.player = player
                                    }
                                },
                                update = {
                                    it.useController = true
                                    it.player = player
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                            if (loadingVideo) {
                                CircularProgressIndicator(
                                    color = PlayerBlue,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            if (playbackError.isNotBlank()) {
                                Text(
                                    playbackError,
                                    color = Color(0xFFFF9BAD),
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .background(Color(0xCC160812))
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                            Icon(
                                Icons.Default.Fullscreen,
                                contentDescription = "Pantalla completa",
                                tint = Color.White,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .size(if (compact) 25.dp else 32.dp)
                            )
                        }

                        CurrentChannelPanel(
                            selected = selected,
                            compact = compact,
                            modifier = Modifier.fillMaxHeight().weight(0.72f)
                        )
                    }

                    GuidePanel(
                        selected = selected,
                        compact = compact,
                        modifier = Modifier.fillMaxWidth().weight(0.95f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelListPanel(
    selected: StreamItem,
    channels: List<StreamItem>,
    categoryTitle: String,
    loading: Boolean,
    compact: Boolean,
    modifier: Modifier,
    onSelect: (StreamItem) -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE8071327))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 48.dp else 64.dp)
                .background(Color(0xEE061020))
                .padding(horizontal = if (compact) 10.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.ArrowBackIosNew, null, modifier = Modifier.size(if (compact) 19.dp else 25.dp))
            Spacer(Modifier.weight(1f))
            Text(
                categoryTitle,
                fontSize = if (compact) 15.sp else 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ArrowForwardIos, null, modifier = Modifier.size(if (compact) 19.dp else 25.dp))
        }

        if (loading && channels.size <= 1) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PlayerBlue)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(channels, key = { it.id }) { channel ->
                    ChannelListRow(
                        channel = channel,
                        selected = channel.id == selected.id,
                        compact = compact,
                        onClick = { onSelect(channel) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelListRow(
    channel: StreamItem,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val active = selected || focused
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .background(if (active) PlayerPurple else Color.Transparent)
            .border(
                if (focused) 2.dp else 0.5.dp,
                if (focused) Color.White else Color(0x553A5277),
                RoundedCornerShape(1.dp)
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = if (compact) 8.dp else 11.dp, vertical = if (compact) 5.dp else 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            channel.id.toString(),
            modifier = Modifier.width(if (compact) 36.dp else 48.dp),
            fontSize = if (compact) 11.sp else 15.sp,
            fontWeight = FontWeight.Bold
        )
        AsyncImage(
            model = channel.image,
            contentDescription = null,
            modifier = Modifier
                .size(if (compact) 38.dp else 52.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(Color.White),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.width(if (compact) 8.dp else 11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                channel.name,
                fontSize = if (compact) 12.sp else 16.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "No se encontró ningún programa",
                color = if (active) Color.White.copy(alpha = 0.86f) else PlayerMuted,
                fontSize = if (compact) 9.sp else 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CurrentChannelPanel(selected: StreamItem, compact: Boolean, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE7071429))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .padding(if (compact) 12.dp else 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AsyncImage(
            model = selected.image,
            contentDescription = null,
            modifier = Modifier
                .size(if (compact) 52.dp else 76.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(if (compact) 8.dp else 13.dp))
        Text(
            "TV EN DIRECTO",
            color = Color.White,
            fontSize = if (compact) 11.sp else 15.sp,
            modifier = Modifier
                .background(PlayerPurple)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(
            selected.name,
            fontSize = if (compact) 15.sp else 21.sp,
            fontWeight = FontWeight.Black,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GuidePanel(selected: StreamItem, compact: Boolean, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .background(Color(0xE7071429))
            .border(1.dp, PlayerLine, RoundedCornerShape(if (compact) 10.dp else 15.dp))
            .padding(if (compact) 14.dp else 20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "GUÍA DEL CANAL",
            color = PlayerBlue,
            fontSize = if (compact) 12.sp else 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(
            "Ahora: no se ha encontrado un programa",
            fontSize = if (compact) 14.sp else 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(if (compact) 5.dp else 8.dp))
        Text(
            "Siguiente: no se encontró ningún programa",
            color = PlayerMuted,
            fontSize = if (compact) 12.sp else 17.sp
        )
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(CircleShape)
                .background(Color(0xFF50647F))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(0.18f)
                    .fillMaxHeight()
                    .background(PlayerBlue)
            )
        }
        Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
        Text(
            selected.name,
            color = Color.White,
            fontSize = if (compact) 11.sp else 15.sp
        )
    }
}
