# FluxPlay v1 - reglas personalizadas se agregarán en versiones posteriores.
