# FluxPlay Android v1.1

Actualización con interfaz horizontal tipo TV, navegación por control remoto, diseño adaptado a pantallas 16:9, reproducción flotante PiP y reproducción en segundo plano mediante Media3 MediaSessionService.
