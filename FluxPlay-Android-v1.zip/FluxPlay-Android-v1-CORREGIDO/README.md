# FluxPlay Android v1

Aplicación Android nativa conectada al panel **FluxPlay Control**.

## Configuración integrada

- API: `https://teletop.online/iptv-panel/api/configuration.php`
- La aplicación obtiene automáticamente la DNS principal y los respaldos.
- Autenticación directa mediante `player_api.php` compatible con Xtream/XUI.
- Paquete Android: `com.fluxplay.app`
- Versión: `1.0.0`

## Incluido en v1

- Pantalla inicial FluxPlay.
- Inicio de sesión con usuario y contraseña.
- Validación contra DNS principal y respaldos.
- Panel principal adaptable a Android TV, TV Box, teléfono y tableta.
- TV en vivo, películas y series.
- Categorías y buscador visual por secciones.
- Episodios de series.
- Reproductor Media3/ExoPlayer.
- Imagen dentro de imagen (PiP).
- Estado, vencimiento y conexiones del usuario.
- Estructura preparada para TV Guide y Catch Up en v2.

## Compilación

Usa Java 17, Android SDK 35, Gradle 8.11.1, AGP 8.10.1 y Kotlin 2.2.0.
El archivo `compilar-fluxplay.yml` permite compilar la APK desde GitHub Actions.

## Corrección de compilación
Se eliminó la importación directa de `layout.weight`. En Compose, `Modifier.weight()` se resuelve desde `RowScope` o `ColumnScope`, evitando el error de acceso a una propiedad interna.
