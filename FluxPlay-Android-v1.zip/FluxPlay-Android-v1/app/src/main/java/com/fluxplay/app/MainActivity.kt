package com.fluxplay.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val FluxBlue = Color(0xFF198BFF)
private val FluxPurple = Color(0xFF7438FF)
private val FluxOrange = Color(0xFFFF7A28)
private val FluxBackground = Color(0xFF050B19)
private val FluxPanel = Color(0xD90B162B)
private val FluxLine = Color(0xFF243A5E)
private val FluxTextMuted = Color(0xFF9EB2CF)

private sealed interface AppScreen {
    data object Splash : AppScreen
    data object Login : AppScreen
    data object Dashboard : AppScreen
    data class Catalog(val type: CatalogType) : AppScreen
    data class SeriesDetail(val series: StreamItem) : AppScreen
    data class Placeholder(val title: String, val message: String) : AppScreen
    data object Settings : AppScreen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = FluxBlue,
                    secondary = FluxPurple,
                    background = FluxBackground,
                    surface = FluxPanel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                FluxPlayApplication()
            }
        }
    }
}

@Composable
private fun FluxPlayApplication() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf<AppScreen>(AppScreen.Splash) }
    var session by remember { mutableStateOf<Session?>(null) }
    var startupError by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        delay(2_000)
        val stored = SessionManager.load(context)
        if (stored == null) {
            screen = AppScreen.Login
            return@LaunchedEffect
        }
        try {
            val config = ApiClient.fetchConfig()
            if (config.maintenance) {
                startupError = config.maintenanceMessage.ifBlank { "Servicio temporalmente en mantenimiento." }
                screen = AppScreen.Login
                return@LaunchedEffect
            }
            val renewed = authenticateUsingConfig(config, stored.username, stored.password)
            SessionManager.save(context, renewed)
            session = renewed
            screen = AppScreen.Dashboard
        } catch (error: Exception) {
            SessionManager.clear(context)
            startupError = "Vuelve a iniciar sesión. ${error.message.orEmpty()}".trim()
            screen = AppScreen.Login
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = FluxBackground) {
        when (val destination = screen) {
            AppScreen.Splash -> SplashScreen()
            AppScreen.Login -> LoginScreen(
                initialError = startupError,
                onLogin = { newSession ->
                    session = newSession
                    SessionManager.save(context, newSession)
                    startupError = ""
                    screen = AppScreen.Dashboard
                }
            )
            AppScreen.Dashboard -> session?.let { activeSession ->
                DashboardScreen(
                    session = activeSession,
                    onOpen = { screen = it },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
            is AppScreen.Catalog -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                CatalogScreen(
                    session = activeSession,
                    type = destination.type,
                    onBack = { screen = AppScreen.Dashboard },
                    onSeries = { screen = AppScreen.SeriesDetail(it) }
                )
            }
            is AppScreen.SeriesDetail -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Catalog(CatalogType.SERIES) }
                SeriesDetailScreen(
                    session = activeSession,
                    series = destination.series,
                    onBack = { screen = AppScreen.Catalog(CatalogType.SERIES) }
                )
            }
            is AppScreen.Placeholder -> {
                BackHandler { screen = AppScreen.Dashboard }
                PlaceholderScreen(destination.title, destination.message) {
                    screen = AppScreen.Dashboard
                }
            }
            AppScreen.Settings -> session?.let { activeSession ->
                BackHandler { screen = AppScreen.Dashboard }
                SettingsScreen(
                    session = activeSession,
                    onBack = { screen = AppScreen.Dashboard },
                    onLogout = {
                        SessionManager.clear(context)
                        session = null
                        screen = AppScreen.Login
                    }
                )
            }
        }
    }
}

private suspend fun authenticateUsingConfig(config: AppConfig, username: String, password: String): Session {
    var lastError: Exception? = null
    for (dns in listOf(config.primaryDns) + config.backupDns) {
        try {
            return ApiClient.authenticate(dns, username, password)
        } catch (error: Exception) {
            lastError = error
        }
    }
    throw lastError ?: IllegalStateException("No fue posible conectar con los servidores configurados.")
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FluxBackground),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginScreen(initialError: String, onLogin: (Session) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember(initialError) { mutableStateOf(initialError) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    BrandedBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val compact = maxWidth < 700.dp
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (compact) 20.dp else 46.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (!compact) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(310.dp),
                            contentScale = ContentScale.Fit
                        )
                        Text(
                            "Tu entretenimiento, conectado siempre.",
                            color = FluxTextMuted,
                            fontSize = 20.sp,
                            modifier = Modifier.padding(start = 34.dp)
                        )
                    }
                    Spacer(Modifier.width(36.dp))
                }

                Column(
                    modifier = Modifier
                        .then(if (compact) Modifier.fillMaxWidth() else Modifier.width(430.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(FluxPanel)
                        .border(1.dp, FluxLine, RoundedCornerShape(28.dp))
                        .padding(30.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (compact) {
                        Image(
                            painter = painterResource(R.drawable.fluxplay_logo),
                            contentDescription = "FluxPlay",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Text("Iniciar sesión", fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text(
                        "Ingresa el usuario y la contraseña entregados por tu proveedor.",
                        color = FluxTextMuted
                    )
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.trim() },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Usuario") },
                        leadingIcon = { Icon(Icons.Default.Person, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Contraseña") },
                        leadingIcon = { Icon(Icons.Default.Lock, null) },
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (errorMessage.isNotBlank()) {
                        Text(
                            errorMessage,
                            color = Color(0xFFFF8EA1),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x332B0010))
                                .padding(12.dp)
                        )
                    }
                    Button(
                        onClick = {
                            if (username.isBlank() || password.isBlank()) {
                                errorMessage = "Escribe el usuario y la contraseña."
                                return@Button
                            }
                            scope.launch {
                                loading = true
                                errorMessage = ""
                                try {
                                    val config = ApiClient.fetchConfig()
                                    if (config.maintenance) {
                                        throw IllegalStateException(config.maintenanceMessage.ifBlank { "Servicio en mantenimiento." })
                                    }
                                    onLogin(authenticateUsingConfig(config, username, password))
                                } catch (error: Exception) {
                                    errorMessage = error.message ?: "No fue posible iniciar sesión."
                                } finally {
                                    loading = false
                                }
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FluxBlue),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(25.dp), strokeWidth = 3.dp)
                        } else {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Entrar a FluxPlay", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        "La DNS se obtiene automáticamente desde FluxPlay Control.",
                        color = FluxTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    session: Session,
    onOpen: (AppScreen) -> Unit,
    onLogout: () -> Unit
) {
    var liveCount by remember { mutableStateOf<Int?>(null) }
    var movieCount by remember { mutableStateOf<Int?>(null) }
    var seriesCount by remember { mutableStateOf<Int?>(null) }
    var countError by remember { mutableStateOf("") }

    LaunchedEffect(session) {
        try {
            coroutineScope {
                val live = async { ApiClient.fetchItems(session, CatalogType.LIVE).size }
                val movies = async { ApiClient.fetchItems(session, CatalogType.MOVIES).size }
                val series = async { ApiClient.fetchItems(session, CatalogType.SERIES).size }
                liveCount = live.await()
                movieCount = movies.await()
                seriesCount = series.await()
            }
        } catch (error: Exception) {
            countError = error.message.orEmpty()
        }
    }

    BrandedBackground {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val showSidebar = maxWidth >= 760.dp
            Row(Modifier.fillMaxSize()) {
                if (showSidebar) {
                    Sidebar(
                        selected = "Inicio",
                        onHome = {},
                        onFavorites = { onOpen(AppScreen.Placeholder("Favoritos", "La biblioteca local de favoritos se activará en la siguiente versión.")) },
                        onSearch = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) },
                        onSettings = { onOpen(AppScreen.Settings) }
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = if (showSidebar) 26.dp else 14.dp, vertical = 18.dp)
                ) {
                    HeaderBar(session)
                    Spacer(Modifier.height(18.dp))
                    if (countError.isNotBlank()) {
                        Text("No se pudieron actualizar algunos contadores: $countError", color = Color(0xFFFFB0BC), fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(if (showSidebar) 260.dp else 190.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            DashboardCard(
                                title = "LIVE TV",
                                subtitle = liveCount?.let { "$it canales disponibles" } ?: "Cargando canales...",
                                icon = Icons.Default.LiveTv,
                                colors = listOf(Color(0xFF0B5BC5), Color(0xFF10244D)),
                                onClick = { onOpen(AppScreen.Catalog(CatalogType.LIVE)) }
                            )
                        }
                        item {
                            DashboardCard(
                                title = "MOVIES",
                                subtitle = movieCount?.let { "$it películas a tu alcance" } ?: "Cargando películas...",
                                icon = Icons.Default.Movie,
                                colors = listOf(Color(0xFF44257D), Color(0xFF17122D)),
                                onClick = { onOpen(AppScreen.Catalog(CatalogType.MOVIES)) }
                            )
                        }
                        item {
                            DashboardCard(
                                title = "SERIES",
                                subtitle = seriesCount?.let { "$it series disponibles" } ?: "Cargando series...",
                                icon = Icons.Default.VideoLibrary,
                                colors = listOf(Color(0xFF7B2D55), Color(0xFF2A1220)),
                                onClick = { onOpen(AppScreen.Catalog(CatalogType.SERIES)) }
                            )
                        }
                        item {
                            DashboardCard(
                                title = "TV GUIDE",
                                subtitle = "Programación y ahora/siguiente",
                                icon = Icons.Default.CalendarMonth,
                                colors = listOf(Color(0xFF3530A3), Color(0xFF151435)),
                                onClick = { onOpen(AppScreen.Placeholder("TV Guide", "La base de la guía está preparada. En la versión 2 conectaremos el EPG completo.")) }
                            )
                        }
                        item {
                            DashboardCard(
                                title = "CATCH UP",
                                subtitle = "Contenido emitido con anterioridad",
                                icon = Icons.Default.History,
                                colors = listOf(Color(0xFF007A7A), Color(0xFF082E36)),
                                onClick = { onOpen(AppScreen.Placeholder("Catch Up", "En la versión 2 activaremos la selección de fecha, hora y duración para canales con archivo.")) }
                            )
                        }
                        item {
                            DashboardCard(
                                title = "AJUSTES",
                                subtitle = "Cuenta, servidor y cierre de sesión",
                                icon = Icons.Default.Settings,
                                colors = listOf(Color(0xFF3B4B62), Color(0xFF111A28)),
                                onClick = { onOpen(AppScreen.Settings) }
                            )
                        }
                    }
                    StatusBar(session, onLogout)
                }
            }
        }
    }
}

@Composable
private fun HeaderBar(session: Session) {
    val time = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) }
    val date = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier.size(width = 190.dp, height = 72.dp),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(time, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(date, color = FluxTextMuted)
        }
    }
}

@Composable
private fun Sidebar(
    selected: String,
    onHome: () -> Unit,
    onFavorites: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(190.dp)
            .fillMaxHeight()
            .background(Color(0xE6050D1B))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.fluxplay_logo),
            contentDescription = "FluxPlay",
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            contentScale = ContentScale.Crop
        )
        NavButton("Inicio", Icons.Default.Home, selected == "Inicio", onHome)
        NavButton("Buscar", Icons.Default.Search, selected == "Buscar", onSearch)
        NavButton("Favoritos", Icons.Default.FavoriteBorder, selected == "Favoritos", onFavorites)
        Spacer(Modifier.weight(1f))
        NavButton("Ajustes", Icons.Default.Settings, selected == "Ajustes", onSettings)
    }
}

@Composable
private fun NavButton(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val background by animateColorAsState(
        if (selected || focused) Color(0xFF123E75) else Color.Transparent,
        label = "nav-background"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .then(if (focused) Modifier.border(2.dp, FluxBlue, RoundedCornerShape(14.dp)) else Modifier)
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected || focused) Color.White else FluxTextMuted)
        Spacer(Modifier.width(12.dp))
        Text(label, fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun DashboardCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    colors: List<Color>,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(205.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(colors))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(22.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x33000000)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, modifier = Modifier.size(30.dp), tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.PlayArrow, null, tint = if (focused) FluxOrange else Color.White)
        }
        Column {
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(7.dp))
            Text(subtitle, color = Color(0xFFD4DDEC), maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            Text("Explorar  ›", color = if (focused) Color.White else Color(0xFFB9D6FF), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatusBar(session: Session, onLogout: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xCC091529))
            .border(1.dp, FluxLine, RoundedCornerShape(18.dp))
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF31E58B)))
        Spacer(Modifier.width(8.dp))
        Text("Conectado: ", color = FluxTextMuted)
        Text(session.username, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("Expira: ", color = FluxTextMuted)
        Text(session.expiration, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Cerrar sesión") }
    }
}

@Composable
private fun CatalogScreen(
    session: Session,
    type: CatalogType,
    onBack: () -> Unit,
    onSeries: (StreamItem) -> Unit
) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var content by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var selectedCategory by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    suspend fun reload() {
        loading = true
        error = ""
        try {
            coroutineScope {
                val categoryJob = async { ApiClient.fetchCategories(session, type) }
                val contentJob = async { ApiClient.fetchItems(session, type) }
                categories = categoryJob.await()
                content = contentJob.await()
            }
        } catch (exception: Exception) {
            error = exception.message ?: "No fue posible cargar el contenido."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(type) { reload() }
    val filtered = remember(content, selectedCategory) {
        if (selectedCategory.isBlank()) content else content.filter { it.categoryId == selectedCategory }
    }

    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(type.title, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(14.dp))
                Text("${filtered.size} elementos", color = FluxTextMuted)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { scope.launch { reload() } }) {
                    Icon(Icons.Default.Refresh, "Actualizar")
                }
            }
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    CategoryChip("Todos", selectedCategory.isBlank()) { selectedCategory = "" }
                }
                items(categories, key = { it.id }) { category ->
                    CategoryChip(category.name, selectedCategory == category.id) { selectedCategory = category.id }
                }
            }
            Spacer(Modifier.height(14.dp))
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FluxBlue)
                }
                error.isNotBlank() -> ErrorPanel(error) { scope.launch { reload() } }
                filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay contenido en esta categoría.", color = FluxTextMuted)
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(175.dp),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filtered, key = { "${type.name}-${it.id}" }) { item ->
                        StreamCard(item) {
                            if (type == CatalogType.SERIES) {
                                onSeries(item)
                            } else {
                                openPlayer(context, session, type, item.id, item.extension, item.name)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(
        label,
        modifier = Modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(50))
            .background(if (selected || focused) FluxBlue else Color(0xFF17243A))
            .border(1.dp, if (focused) Color.White else FluxLine, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 17.dp, vertical = 10.dp),
        color = Color.White,
        fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1
    )
}

@Composable
private fun StreamCard(item: StreamItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (item.image.isNotBlank()) {
                AsyncImage(
                    model = item.image,
                    contentDescription = item.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            } else {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(55.dp), tint = FluxTextMuted)
            }
        }
        Spacer(Modifier.height(9.dp))
        Text(item.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (item.rating.isNotBlank()) {
            Text("★ ${item.rating}", color = Color(0xFFFFC862), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SeriesDetailScreen(session: Session, series: StreamItem, onBack: () -> Unit) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }

    LaunchedEffect(series.id) {
        try {
            episodes = ApiClient.fetchSeriesEpisodes(session, series.id)
        } catch (exception: Exception) {
            error = exception.message ?: "No fue posible cargar los episodios."
        } finally {
            loading = false
        }
    }

    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(series.name, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(12.dp))
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error.isNotBlank() -> ErrorPanel(error, onBack)
                episodes.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Esta serie no devolvió episodios.", color = FluxTextMuted)
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(episodes, key = { it.id }) { episode ->
                        EpisodeRow(episode) {
                            openPlayer(context, session, CatalogType.SERIES, episode.id, episode.extension, episode.title)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(episode: Episode, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xE80B162B))
            .border(if (focused) 3.dp else 1.dp, if (focused) FluxBlue else FluxLine, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .focusable()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 140.dp, height = 82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF101D32)),
            contentAlignment = Alignment.Center
        ) {
            if (episode.image.isNotBlank()) {
                AsyncImage(episode.image, episode.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text("Temporada ${episode.season} · Episodio ${episode.number}", color = FluxBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(episode.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (episode.description.isNotBlank()) {
                Text(episode.description, color = FluxTextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp))
    }
}

@Composable
private fun PlaceholderScreen(title: String, message: String, onBack: () -> Unit) {
    BrandedBackground {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text(title, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier
                        .width(520.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(FluxPanel)
                        .border(1.dp, FluxLine, RoundedCornerShape(24.dp))
                        .padding(30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Settings, null, modifier = Modifier.size(65.dp), tint = FluxPurple)
                    Spacer(Modifier.height(16.dp))
                    Text("Módulo preparado", fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Text(message, color = FluxTextMuted)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(session: Session, onBack: () -> Unit, onLogout: () -> Unit) {
    BrandedBackground {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Regresar") }
                Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(20.dp))
            SettingsValue("Usuario", session.username)
            SettingsValue("DNS activa", session.baseUrl)
            SettingsValue("Estado", session.status)
            SettingsValue("Vencimiento", session.expiration)
            SettingsValue("Conexiones", "${session.activeConnections} de ${session.maxConnections}")
            SettingsValue("Tipo de cuenta", if (session.isTrial) "Prueba" else "Normal")
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB42345)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }
    }
}

@Composable
private fun SettingsValue(label: String, value: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(FluxPanel)
            .border(1.dp, FluxLine, RoundedCornerShape(15.dp))
            .padding(15.dp)
    ) {
        Text(label, color = FluxTextMuted, fontSize = 12.sp)
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ErrorPanel(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(message, color = Color(0xFFFF9AAC))
            Spacer(Modifier.height(14.dp))
            Button(onClick = onRetry) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Reintentar")
            }
        }
    }
}

@Composable
private fun BrandedBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(FluxBackground)) {
        Image(
            painter = painterResource(R.drawable.flux_background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.30f
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xE6050B19)),
                        radius = 1200f
                    )
                )
        )
        content()
    }
}

private fun openPlayer(
    context: Context,
    session: Session,
    type: CatalogType,
    itemId: Int,
    extension: String,
    title: String
) {
    val safeUser = Uri.encode(session.username)
    val safePassword = Uri.encode(session.password)
    val safeExtension = extension.ifBlank { if (type == CatalogType.LIVE) "ts" else "mp4" }
    val url = "${session.baseUrl.trimEnd('/')}/${type.route}/$safeUser/$safePassword/$itemId.$safeExtension"
    context.startActivity(
        Intent(context, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, url)
            .putExtra(PlayerActivity.EXTRA_TITLE, title)
    )
}
